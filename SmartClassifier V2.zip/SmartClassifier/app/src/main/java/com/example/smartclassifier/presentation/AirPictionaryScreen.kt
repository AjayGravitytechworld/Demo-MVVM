package com.example.smartclassifier.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.smartclassifier.presentation.ar.DoodleRecognizer
import com.example.smartclassifier.presentation.ar.DoodleTheme
import com.example.smartclassifier.presentation.ar.Doodle
import com.example.smartclassifier.presentation.ar.HandPose
import com.example.smartclassifier.presentation.ar.HandTracker
import com.example.smartclassifier.presentation.ar.InkPoint
import com.example.smartclassifier.presentation.ar.Scene
import com.example.smartclassifier.presentation.ar.buildDoodle
import com.example.smartclassifier.presentation.ar.doodleScale
import com.example.smartclassifier.presentation.ar.drawAliveDoodle
import com.example.smartclassifier.presentation.ar.drawFx
import com.example.smartclassifier.presentation.ar.drawScene
import com.example.smartclassifier.presentation.ar.smoothPath
import com.example.smartclassifier.presentation.ar.themeFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.max

private enum class Phase { DRAW, THINKING, RESULT }

private enum class GameMode(val label: String) {
    CHALLENGE("🎯 Challenge"),
    FREE("🎨 Free")
}

private val WORDS = listOf(
    "cat", "fish", "sun", "tree", "flower", "bird", "house", "car",
    "apple", "star", "heart", "cloud", "butterfly", "dog", "moon", "balloon"
)
private const val ROUND_SECONDS = 30f

private fun norm(s: String) = s.lowercase().replace('_', ' ').replace('-', ' ').trim()

private fun isMatch(target: String, cand: String): Boolean {
    val c = norm(cand)
    if (c.length < 3) return false
    return c == target || c.split(' ').contains(target) || (c.length >= 5 && target.contains(c))
}

private class PicPen {
    var sx = -1f
    var sy = -1f
    var down = 0
    var up = 0
    val pending = mutableListOf<InkPoint>()
}

private fun DrawScope.drawInk(pts: List<InkPoint>) {
    if (pts.size < 2) return
    val path = smoothPath(pts.map { Offset(it.x, it.y) })
    drawPath(path, Color(0xFF00E5FF).copy(alpha = 0.28f), style = Stroke(24f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(path, Color.White, style = Stroke(8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

@Composable
fun AirPictionaryScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // Camera is optional – finger drawing works even if permission is denied
    var cameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var asked by rememberSaveable { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        cameraGranted = it
    }
    LaunchedEffect(Unit) {
        if (!cameraGranted && !asked) {
            asked = true
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // ── State ────────────────────────────────────────────────────────────────
    var modeOrd by rememberSaveable { mutableIntStateOf(0) }
    val mode = GameMode.values()[modeOrd]
    var phase by remember { mutableStateOf(Phase.DRAW) }
    var target by rememberSaveable { mutableStateOf(WORDS.random()) }
    var round by remember { mutableIntStateOf(0) }
    var timeLeft by remember { mutableFloatStateOf(ROUND_SECONDS) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var best by rememberSaveable { mutableIntStateOf(0) }
    var streak by rememberSaveable { mutableIntStateOf(0) }

    val strokes = remember { mutableStateListOf<List<InkPoint>>() }
    val live = remember { mutableStateListOf<InkPoint>() }
    var isPenDown by remember { mutableStateOf(false) }
    var touchActive by remember { mutableStateOf(false) }
    var cursor by remember { mutableStateOf<Offset?>(null) }
    var handSeen by remember { mutableStateOf(false) }
    var canvasW by remember { mutableFloatStateOf(1080f) }
    var canvasH by remember { mutableFloatStateOf(1920f) }
    var modelLoading by remember { mutableStateOf(true) }

    // result
    var candidates by remember { mutableStateOf<List<String>>(emptyList()) }
    var selected by remember { mutableIntStateOf(0) }
    var theme by remember { mutableStateOf<DoodleTheme?>(null) }
    var doodle by remember { mutableStateOf<Doodle?>(null) }
    var won by remember { mutableStateOf<Boolean?>(null) }
    var gained by remember { mutableIntStateOf(0) }
    var t by remember { mutableFloatStateOf(0f) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val pen = remember { PicPen() }
    val recognizer = remember { DoodleRecognizer() }
    val tracker = remember { HandTracker(context.applicationContext) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    LaunchedEffect(tracker) {
        val err = withContext(Dispatchers.IO) { tracker.prepare() }
        modelLoading = false
        if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
    }
    DisposableEffect(Unit) {
        onDispose {
            tracker.close()
            recognizer.close()
            executor.shutdown()
        }
    }

    // ── Actions ──────────────────────────────────────────────────────────────
    fun commitLive() {
        if (live.size >= 3) strokes.add(live.toList())
        live.clear()
    }

    fun startRound() {
        strokes.clear()
        live.clear()
        isPenDown = false
        pen.down = 0
        pen.up = 0
        pen.pending.clear()
        pen.sx = -1f
        won = null
        doodle = null
        candidates = emptyList()
        errorMsg = null
        if (mode == GameMode.CHALLENGE) {
            var w = WORDS.random()
            while (w == target && WORDS.size > 1) w = WORDS.random()
            target = w
        }
        timeLeft = ROUND_SECONDS
        round++
        phase = Phase.DRAW
    }

    fun finish() {
        if (phase != Phase.DRAW) return
        commitLive()
        isPenDown = false
        if (strokes.isEmpty()) {
            Toast.makeText(context, "Draw something first ✏", Toast.LENGTH_SHORT).show()
            return
        }
        phase = Phase.THINKING
        val snapshot = strokes.map { it.toList() }
        scope.launch {
            val cands = try {
                recognizer.recognize(snapshot)
            } catch (e: Exception) {
                errorMsg = "AI model error: ${e.message} (internet needed once)"
                emptyList()
            }
            val list = if (cands.isEmpty()) listOf("doodle") else cands.take(5)

            var idx = 0
            var win: Boolean? = null
            if (mode == GameMode.CHALLENGE) {
                val hit = list.indexOfFirst { isMatch(target, it) }
                win = hit >= 0
                if (hit >= 0) idx = hit
            }
            val label = if (win == true) target else list[idx]
            theme = themeFor(label)
            doodle = buildDoodle(snapshot.map { s -> s.map { Offset(it.x, it.y) } })
            candidates = list
            selected = idx
            won = win
            if (win == true) {
                gained = 100 + (timeLeft * 3f).toInt() + streak * 20
                score += gained
                streak++
                best = max(best, score)
            } else if (win == false) {
                gained = 0
                streak = 0
            }
            t = 0f
            phase = Phase.RESULT
        }
    }

    // Challenge timer
    LaunchedEffect(phase, round, modeOrd) {
        if (phase == Phase.DRAW && mode == GameMode.CHALLENGE) {
            timeLeft = ROUND_SECONDS
            while (timeLeft > 0f) {
                delay(100)
                timeLeft -= 0.1f
            }
            if (strokes.isEmpty() && live.size < 3) {
                Toast.makeText(context, "⏰ Time up!", Toast.LENGTH_SHORT).show()
                streak = 0
                startRound()
            } else finish()
        }
    }

    // Animation clock (only while showing the living doodle)
    LaunchedEffect(phase) {
        if (phase == Phase.RESULT) {
            var start = -1L
            while (true) {
                androidx.compose.runtime.withFrameNanos { now ->
                    if (start < 0) start = now
                    t = (now - start) / 1_000_000_000f
                }
            }
        }
    }

    // ── Hand pinch drawing (MAIN thread) ─────────────────────────────────────
    fun handleHand(pose: HandPose?) {
        if (phase != Phase.DRAW || touchActive) return
        if (pose == null) {
            handSeen = false
            cursor = null
            pen.down = 0
            pen.up++
            pen.pending.clear()
            if (isPenDown && pen.up >= 6) {
                commitLive()
                isPenDown = false
            }
            if (!isPenDown) pen.sx = -1f
            return
        }
        handSeen = true

        val aw = pose.imgW
        val ah = pose.imgH
        val sc = maxOf(canvasW / aw, canvasH / ah)
        val offX = (aw * sc - canvasW) / 2f
        val offY = (ah * sc - canvasH) / 2f
        val tx = (aw - pose.pinchCenterX) * sc - offX      // front camera is mirrored
        val ty = pose.pinchCenterY * sc - offY

        if (pen.sx < 0f) {
            pen.sx = tx
            pen.sy = ty
        } else {
            val speed = hypot(tx - pen.sx, ty - pen.sy)
            val a = (0.25f + speed / 90f).coerceIn(0.25f, 0.9f)
            pen.sx += a * (tx - pen.sx)
            pen.sy += a * (ty - pen.sy)
        }
        val cur = Offset(pen.sx, pen.sy)
        cursor = cur

        val r = pose.pinchRatio
        val wantRaw = if (isPenDown) r < 0.60f else r < 0.35f
        if (wantRaw) {
            pen.down++
            pen.up = 0
        } else {
            pen.up++
            pen.down = 0
        }

        val now = SystemClock.uptimeMillis()
        if (!isPenDown) {
            if (wantRaw) {
                pen.pending.add(InkPoint(cur.x, cur.y, now))
                if (pen.down >= 2) {
                    isPenDown = true
                    live.clear()
                    live.addAll(pen.pending)
                    pen.pending.clear()
                }
            } else pen.pending.clear()
        } else {
            if (wantRaw) {
                val last = live.lastOrNull()
                if (last == null || hypot(cur.x - last.x, cur.y - last.y) >= 4f) {
                    live.add(InkPoint(cur.x, cur.y, now))
                }
            } else if (pen.up >= 3) {
                commitLive()
                isPenDown = false
            }
        }
    }
    val onHand = rememberUpdatedState<(HandPose?) -> Unit>(newValue = { handleHand(it) })

    // ── Camera (front) ───────────────────────────────────────────────────────
    DisposableEffect(lifecycleOwner, cameraGranted) {
        var provider: ProcessCameraProvider? = null
        if (cameraGranted) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                val p = future.get()
                provider = p
                p.unbindAll()
                val preview = Preview.Builder().build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { proxy: ImageProxy ->
                    try {
                        if (!tracker.ready || phase != Phase.DRAW) return@setAnalyzer
                        val rotation = proxy.imageInfo.rotationDegrees
                        val raw = proxy.toBitmap()
                        val upright = if (rotation != 0) {
                            Bitmap.createBitmap(
                                raw, 0, 0, raw.width, raw.height,
                                Matrix().apply { postRotate(rotation.toFloat()) }, true
                            )
                        } else raw
                        val pose = tracker.detect(upright, SystemClock.uptimeMillis())
                        mainHandler.post { onHand.value(pose) }
                    } catch (_: Exception) {
                    } finally {
                        proxy.close()
                    }
                }
                try {
                    p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
                } catch (e: Exception) {
                    Toast.makeText(context, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }, ContextCompat.getMainExecutor(context))
        }
        onDispose { provider?.unbindAll() }
    }

    // ── UI ───────────────────────────────────────────────────────────────────
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF12121C))
            .onSizeChanged {
                canvasW = it.width.toFloat()
                canvasH = it.height.toFloat()
            }
    ) {
        if (cameraGranted) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (cameraGranted) 0.35f else 0f)))

        // ── Drawing layer (strokes + touch input) ──
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(phase) {
                    if (phase == Phase.DRAW) {
                        detectDragGestures(
                            onDragStart = { off ->
                                touchActive = true
                                live.clear()
                                live.add(InkPoint(off.x, off.y, SystemClock.uptimeMillis()))
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val last = live.lastOrNull()
                                val p = change.position
                                if (last == null || hypot(p.x - last.x, p.y - last.y) >= 3f) {
                                    live.add(InkPoint(p.x, p.y, SystemClock.uptimeMillis()))
                                }
                            },
                            onDragEnd = {
                                commitLive()
                                touchActive = false
                            },
                            onDragCancel = {
                                commitLive()
                                touchActive = false
                            }
                        )
                    }
                }
        ) {
            if (phase != Phase.RESULT) {
                strokes.forEach { drawInk(it) }
                drawInk(live.toList())
                cursor?.let { c ->
                    drawCircle(
                        if (isPenDown) Color(0xFFFFC107) else Color.White.copy(alpha = 0.8f),
                        if (isPenDown) 14f else 22f, c,
                        style = if (isPenDown) androidx.compose.ui.graphics.drawscope.Fill else Stroke(4f)
                    )
                }
            }
        }

        // ── RESULT: living doodle stage ──
        if (phase == Phase.RESULT) {
            Canvas(Modifier.fillMaxSize()) {
                val th = theme
                val d = doodle
                if (th != null && d != null) {
                    val groundY = size.height * 0.80f
                    val hasGround = th.scene == Scene.GROUND
                    drawScene(th.scene, t, groundY)
                    val k = doodleScale(size)
                    val cx = size.width / 2f
                    val cy = if (hasGround) groundY - d.h * k / 2f - size.height * 0.02f else size.height * 0.45f
                    drawFx(th.fx, t, groundY, Offset(cx, cy), d.w * k * 0.7f)
                    drawAliveDoodle(d, th, t, (t / 0.9f), cx, cy, if (hasGround) groundY else null)
                    if (won == true) {
                        drawFx(com.example.smartclassifier.presentation.ar.Fx.SPARKLE, t, groundY, Offset(cx, cy), d.w * k * 0.9f)
                    }
                }
            }
        }

        // ── Top overlay ──
        Column(
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (phase == Phase.DRAW) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GameMode.values().forEach { m ->
                        val sel = m == mode
                        Text(
                            m.label,
                            color = if (sel) Color.Black else Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .background(if (sel) Color(0xFFFFC107) else Color.Black.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .clickable {
                                    modeOrd = m.ordinal
                                    startRound()
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
                if (mode == GameMode.CHALLENGE) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.65f)) {
                        Column(Modifier.padding(horizontal = 18.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "Draw: ${themeFor(target).emoji} ${target.uppercase()}",
                                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(4.dp))
                            Box(
                                Modifier.fillMaxWidth(0.7f).height(8.dp)
                                    .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    Modifier.fillMaxHeight()
                                        .fillMaxWidth((timeLeft / ROUND_SECONDS).coerceIn(0f, 1f))
                                        .background(if (timeLeft < 8f) Color(0xFFFF5252) else Color(0xFF69F0AE), RoundedCornerShape(4.dp))
                                )
                            }
                            Text("⏱ ${timeLeft.toInt()}s   ⭐ $score   🔥 $streak   🏆 $best", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
                Surface(shape = RoundedCornerShape(50), color = Color.Black.copy(alpha = 0.55f)) {
                    Text(
                        when {
                            isPenDown || touchActive -> "✍ Drawing…"
                            cameraGranted && modelLoading -> "⏳ Loading hand model… (or draw with finger)"
                            cameraGranted && handSeen -> "🤏 Pinch thumb + index to draw"
                            cameraGranted -> "🖐 Show hand & pinch — or draw with your finger"
                            else -> "👆 Draw with your finger"
                        },
                        color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                    )
                }
            }

            if (phase == Phase.RESULT) {
                val th = theme
                val label = candidates.getOrNull(selected) ?: "doodle"
                Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.6f)) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${th?.emoji ?: "✨"}  AI sees: $label", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        when (won) {
                            true -> Text("✅ Correct! +$gained   ⭐ $score   🔥 $streak", color = Color(0xFF69F0AE), fontSize = 14.sp)
                            false -> Text("❌ Target was “$target”   ⭐ $score", color = Color(0xFFFF8A80), fontSize = 14.sp)
                            null -> Text("Wrong guess? Tap another one below 👇", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        }
                        errorMsg?.let { Text(it, color = Color(0xFFFFCC80), fontSize = 11.sp) }
                    }
                }
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    candidates.forEachIndexed { i, cand ->
                        val sel = i == selected
                        Text(
                            cand,
                            color = if (sel) Color.Black else Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .background(if (sel) Color(0xFFFFC107) else Color.Black.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                                .clickable {
                                    selected = i
                                    theme = themeFor(cand)
                                    t = 0f
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // ── Thinking overlay ──
        if (phase == Phase.THINKING) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Color(0xFFFFC107))
                Spacer(Modifier.height(10.dp))
                Text("🤖 AI is guessing…", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("(first time it downloads the drawing model – internet needed once)", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
            }
        }

        Row(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when (phase) {
                Phase.DRAW -> {
                    OutlinedButton(
                        onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) },
                        modifier = Modifier.weight(1f)
                    ) { Text("↩ Undo", color = Color.White) }
                    OutlinedButton(
                        onClick = { strokes.clear(); live.clear(); isPenDown = false },
                        modifier = Modifier.weight(1f)
                    ) { Text("🗑 Clear", color = Color.White) }
                    Button(onClick = { finish() }, modifier = Modifier.weight(1.4f)) { Text("✅ Done") }
                }
                Phase.RESULT -> {
                    Button(onClick = { startRound() }, modifier = Modifier.weight(1f)) {
                        Text(if (mode == GameMode.CHALLENGE) "➡ Next word" else "✏ Draw another")
                    }
                }
                Phase.THINKING -> Unit
            }
        }
    }
}
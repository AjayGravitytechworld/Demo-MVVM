package com.example.smartclassifier.presentation

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.Executors

// ── Timing (ms) – tweak here ────────────────────────────────────────────────
private const val DOT_MS = 200L          // eyes closed  200–650  ms = •
private const val DASH_MS = 650L         // eyes closed  650–2500 ms = —
private const val DELETE_MS = 2500L      // eyes closed  2.5 s+       = delete
private const val LETTER_GAP_MS = 1400L  // eyes open this long       = letter done
private const val WORD_GAP_MS = 3400L    // eyes open this long       = space
private const val MAX_SYMBOLS = 5

private val MORSE: Map<String, Char> = mapOf(
    ".-" to 'A', "-..." to 'B', "-.-." to 'C', "-.." to 'D', "." to 'E', "..-." to 'F',
    "--." to 'G', "...." to 'H', ".." to 'I', ".---" to 'J', "-.-" to 'K', ".-.." to 'L',
    "--" to 'M', "-." to 'N', "---" to 'O', ".--." to 'P', "--.-" to 'Q', ".-." to 'R',
    "..." to 'S', "-" to 'T', "..-" to 'U', "...-" to 'V', ".--" to 'W', "-..-" to 'X',
    "-.--" to 'Y', "--.." to 'Z',
    "-----" to '0', ".----" to '1', "..---" to '2', "...--" to '3', "....-" to '4',
    "....." to '5', "-...." to '6', "--..." to '7', "---.." to '8', "----." to '9'
)

private fun pretty(seq: String) = seq.map { if (it == '.') "•" else "—" }.joinToString(" ")

private class MorseHold {
    var closed = false
    var closeStart = 0L
    var lastEvent = 0L
}

/**
 * Blink Morse – type text with your EYES only (accessibility feature).
 * Slow blink  = •   |  long close = —  |  2.5 s close = delete
 * Open eyes 1.4 s = letter done  |  3.4 s = space
 */
@Composable
fun BlinkMorseScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current

    // ── Permission ───────────────────────────────────────────────────────────
    fun granted() = ContextCompat.checkSelfPermission(
        context, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    var cameraGranted by remember { mutableStateOf(granted()) }
    var asked by rememberSaveable { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { cameraGranted = granted() }

    LaunchedEffect(Unit) {
        if (!cameraGranted && !asked) {
            asked = true
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    if (!cameraGranted) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Camera permission is required for Blink Morse", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text("Grant permission") }
            TextButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                    })
            }) { Text("Open Settings") }
        }
        return
    }

    // ── State ────────────────────────────────────────────────────────────────
    var seq by remember { mutableStateOf("") }
    var text by rememberSaveable { mutableStateOf("") }
    var faceSeen by remember { mutableStateOf(false) }
    var eyesClosed by remember { mutableStateOf(false) }
    var closeMs by remember { mutableFloatStateOf(0f) }
    var lastInfo by remember { mutableStateOf("") }
    var showCheat by remember { mutableStateOf(false) }

    val hold = remember { MorseHold() }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val detector = remember {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .setMinFaceSize(0.25f)
                .build()
        )
    }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    // Text-to-speech
    val ttsHolder = remember { arrayOfNulls<TextToSpeech>(1) }
    DisposableEffect(Unit) {
        ttsHolder[0] = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) ttsHolder[0]?.language = Locale.getDefault()
        }
        onDispose {
            ttsHolder[0]?.stop()
            ttsHolder[0]?.shutdown()
            detector.close()
            executor.shutdown()
        }
    }

    // ── Morse logic ──────────────────────────────────────────────────────────
    fun addSymbol(c: Char) {
        hold.lastEvent = SystemClock.uptimeMillis()
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (seq.length >= MAX_SYMBOLS) {
            seq = ""
            lastInfo = "Too long – cleared"
        } else {
            seq += c
        }
    }

    fun backspace() {
        hold.lastEvent = SystemClock.uptimeMillis()
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (seq.isNotEmpty()) seq = seq.dropLast(1)
        else if (text.isNotEmpty()) text = text.dropLast(1)
    }

    fun onBlinkFinished(durationMs: Long) {
        when {
            durationMs >= DELETE_MS -> backspace()
            durationMs >= DASH_MS -> addSymbol('-')
            durationMs >= DOT_MS -> addSymbol('.')
            else -> Unit // natural quick blink -> ignored
        }
    }

    fun onFaces(faces: List<Face>) {
        val now = SystemClock.uptimeMillis()
        val face = faces.maxByOrNull { it.boundingBox.width() }
        if (face == null) {
            faceSeen = false
            hold.closed = false
            eyesClosed = false
            closeMs = 0f
            return
        }
        val l = face.leftEyeOpenProbability
        val r = face.rightEyeOpenProbability
        if (l == null || r == null) return
        faceSeen = true

        val open = (l + r) / 2f
        if (!hold.closed && open < 0.30f) {
            hold.closed = true
            hold.closeStart = now
        } else if (hold.closed && open > 0.60f) {
            hold.closed = false
            val dur = now - hold.closeStart
            closeMs = 0f
            eyesClosed = false
            onBlinkFinished(dur)
            return
        }
        eyesClosed = hold.closed
        closeMs = if (hold.closed) (now - hold.closeStart).toFloat() else 0f
    }
    val onFacesState = rememberUpdatedState<(List<Face>) -> Unit>(newValue = { onFaces(it) })

    // Letter / word timers
    LaunchedEffect(Unit) {
        while (true) {
            delay(100)
            val now = SystemClock.uptimeMillis()
            if (hold.closed || hold.lastEvent == 0L) continue
            val gap = now - hold.lastEvent
            if (seq.isNotEmpty() && gap >= LETTER_GAP_MS) {
                val ch = MORSE[seq]
                if (ch != null) {
                    text += ch
                    lastInfo = "$ch  ${pretty(seq)}"
                } else {
                    lastInfo = "? ${pretty(seq)} – not a letter"
                }
                seq = ""
            } else if (seq.isEmpty() && text.isNotEmpty() && !text.endsWith(" ") && gap >= WORD_GAP_MS) {
                text += " "
            }
        }
    }

    // ── Camera + ML Kit face analysis ────────────────────────────────────────
    DisposableEffect(lifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null

        future.addListener({
            val p = future.get()
            provider = p
            p.unbindAll()

            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(executor) { proxy: ImageProxy ->
                val media = proxy.image
                if (media == null) {
                    proxy.close()
                    return@setAnalyzer
                }
                val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                detector.process(input)
                    .addOnSuccessListener { faces -> onFacesState.value(faces) }
                    .addOnCompleteListener { proxy.close() }
            }

            try {
                p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
            } catch (e: Exception) {
                Toast.makeText(context, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose { provider?.unbindAll() }
    }

    // ── UI ───────────────────────────────────────────────────────────────────
    val zoneColor = when {
        closeMs >= DELETE_MS -> Color(0xFFFF5252)
        closeMs >= DASH_MS -> Color(0xFFFF9800)
        closeMs >= DOT_MS -> Color(0xFF40C4FF)
        else -> Color.Gray
    }
    val zoneLabel = when {
        !eyesClosed -> "Eyes open"
        closeMs >= DELETE_MS -> "🗑 DELETE (open eyes)"
        closeMs >= DASH_MS -> "— DASH"
        closeMs >= DOT_MS -> "• DOT"
        else -> "…keep closing"
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Camera
        Box(
            modifier = Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(20.dp)).background(Color.Black)
        ) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
            Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.6f)
            ) {
                Text(
                    if (faceSeen) "👁 $zoneLabel" else "❓ Show your face",
                    color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }

        // Closure meter
        Box(
            modifier = Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp))
                .background(Color.Gray.copy(alpha = 0.25f))
        ) {
            Box(
                Modifier.fillMaxHeight()
                    .fillMaxWidth((closeMs / (DELETE_MS + 500f)).coerceIn(0f, 1f))
                    .background(zoneColor)
            )
        }

        // Current sequence
        Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF1E1E2C), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (seq.isEmpty()) "—  blink to start  —" else pretty(seq),
                    color = Color.White, fontSize = 30.sp, fontFamily = FontFamily.Monospace
                )
                val guess = MORSE[seq]
                Text(
                    when {
                        seq.isNotEmpty() && guess != null -> "= $guess"
                        seq.isNotEmpty() -> "…"
                        lastInfo.isNotEmpty() -> "last: $lastInfo"
                        else -> ""
                    },
                    color = Color(0xFFFFC107), fontSize = 16.sp
                )
            }
        }

        // Output text
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF263238),
            modifier = Modifier.fillMaxWidth().height(110.dp)
        ) {
            Text(
                if (text.isEmpty()) "Your text appears here…" else text,
                color = if (text.isEmpty()) Color.Gray else Color.White,
                fontSize = 24.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(14.dp)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    if (text.isNotBlank()) ttsHolder[0]?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "morse")
                },
                modifier = Modifier.weight(1f)
            ) { Text("🔊 Speak") }
            OutlinedButton(
                onClick = {
                    clipboard.setText(AnnotatedString(text))
                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f)
            ) { Text("📋 Copy") }
            OutlinedButton(
                onClick = {
                    if (text.isNotBlank()) {
                        context.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, text)
                                }, "Send"
                            )
                        )
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("📤 Send") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { text = ""; seq = ""; lastInfo = "" }, modifier = Modifier.weight(1f)) {
                Text("🗑 Clear")
            }
            OutlinedButton(onClick = { showCheat = !showCheat }, modifier = Modifier.weight(1f)) {
                Text(if (showCheat) "Hide Morse chart" else "📖 Morse chart")
            }
        }

        Text(
            "Slow blink = •   Long close = —   Close 2.5s = delete\nOpen eyes 1.4s = letter done   3.4s = space",
            color = Color.Gray, fontSize = 12.sp
        )

        if (showCheat) {
            val rows = MORSE.entries.sortedBy { it.value }.chunked(3)
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF1E1E2C), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    rows.forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { e ->
                                Text(
                                    "${e.value}  ${pretty(e.key)}",
                                    color = Color.White, fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
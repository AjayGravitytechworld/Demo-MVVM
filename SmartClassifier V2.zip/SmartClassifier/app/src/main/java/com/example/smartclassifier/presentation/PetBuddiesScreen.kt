package com.example.smartclassifier.presentation

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.PixelCopy
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.smartclassifier.presentation.ar.AnimalKind
import com.example.smartclassifier.presentation.ar.Pz
import com.example.smartclassifier.presentation.ar.SPECIES
import com.example.smartclassifier.presentation.ar.Species
import com.example.smartclassifier.presentation.ar.bell
import com.example.smartclassifier.presentation.ar.drawAnimal
import com.example.smartclassifier.presentation.ar.easeOutBack
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

// ── model ────────────────────────────────────────────────────────────────────
private const val SPOT_HEAD = 0
private const val SPOT_GLASSES = 1
private const val SPOT_SH_L = 2
private const val SPOT_SH_R = 3
private val SPOT_DELAY = floatArrayOf(0f, 0.25f, 0.45f, 0.60f)
private val SPOT_RATE = floatArrayOf(16f, 18f, 7f, 7f)

private enum class Act { IDLE, WAVE, YAWN, LOOK, SLEEP, EAT, DANCE, KISS, EARS, JUMP }

private class Anim(val spot: Int, var sp: Species, var born: Float) {
    var init = false
    var x = 0f
    var y = 0f
    var rot = 0f
    var size = 1f
    var tx = 0f
    var ty = 0f
    var trot = 0f
    var tsize = 1f

    var act = Act.IDLE
    var actStart = born
    var actEnd = born + 1.2f + Random.nextFloat() * 1.5f
    var userSleep = false
    var happyCooldown = 0f
    var nextBlink = born + 1f + Random.nextFloat() * 3f
    var blinkStart = -10f

    // eyes: random glances (no fixed loop)
    var eyeX = 0f
    var eyeY = 0f
    var eyeTX = 0f
    var eyeTY = 0f
    var nextGlance = born + 0.5f + Random.nextFloat() * 2f

    // tiny random head wobble
    var micro = 0f
    var microTarget = 0f
    var nextMicro = born + 1f + Random.nextFloat() * 2f
    var jiggle = 0f
    var boop = -10f
    val pz = Pz()
}

private class Rig(val id: Int, born: Float) {
    val anims = Array(4) { spot -> Anim(spot, SPECIES[0], born) }
    var lastSeen = born
    var happy = false
    var sleepyUser = false
    var eyesClosedSince = -1f
    var eyeA = Offset.Zero
    var eyeB = Offset.Zero
    var lens = 0f
    var rot = 0f
    var hasEyes = false
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun assignSpecies(rig: Rig, now: Float) {
    val picks = SPECIES.shuffled()
    rig.anims.forEachIndexed { i, a ->
        a.sp = picks[i % picks.size]
        a.born = now
        a.act = Act.IDLE
        a.actStart = now
        a.actEnd = now + 1.5f + Random.nextFloat() * 1.5f
    }
}

private fun hasEars(k: AnimalKind) = when (k) {
    AnimalKind.CAT, AnimalKind.DOG, AnimalKind.BUNNY, AnimalKind.FOX,
    AnimalKind.PIG, AnimalKind.OWL, AnimalKind.BEAR, AnimalKind.PANDA -> true
    else -> false
}

private fun actDuration(a: Act): Float = when (a) {
    Act.IDLE -> 2f
    Act.WAVE -> 2.4f
    Act.YAWN -> 1.8f
    Act.LOOK -> 2.6f
    Act.SLEEP -> 3.5f
    Act.EAT -> 3.2f
    Act.DANCE -> 3.2f
    Act.KISS -> 2.4f
    Act.EARS -> 1.0f
    Act.JUMP -> 1.2f
}

private fun beginAct(a: Anim, act: Act, now: Float, dur: Float = actDuration(act)) {
    a.act = act
    a.actStart = now
    a.actEnd = now + dur
}

private fun pickAct(a: Anim): Act {
    val pool = mutableListOf(
        Act.WAVE, Act.WAVE, Act.YAWN, Act.LOOK, Act.LOOK, Act.EAT, Act.EAT,
        Act.DANCE, Act.KISS, Act.KISS, Act.JUMP, Act.SLEEP
    )
    if (hasEars(a.sp.kind)) {
        pool.add(Act.EARS)
        pool.add(Act.EARS)
    }
    return pool.random()
}

private fun updateAnim(a: Anim, rig: Rig, now: Float, dt: Float) {
    if (!a.init) {
        a.x = a.tx; a.y = a.ty; a.rot = a.trot; a.size = a.tsize
        a.init = true
    }
    val k = 1f - exp(-dt * SPOT_RATE[a.spot])
    val lag = hypot(a.tx - a.x, a.ty - a.y) / max(a.size, 1f)
    a.x += (a.tx - a.x) * k
    a.y += (a.ty - a.y) * k
    a.size += (a.tsize - a.size) * k
    a.rot += (a.trot - a.rot) * (1f - exp(-dt * 9f))
    a.jiggle += (lag - a.jiggle) * 0.15f

    // ── eyes: random glances left/right/up/down – sometimes none at all
    if (now >= a.nextGlance) {
        val r = Random.nextFloat()
        if (a.act == Act.LOOK) {
            a.eyeTX = Random.nextFloat() * 2f - 1f
            a.eyeTY = (Random.nextFloat() * 2f - 1f) * 0.6f
            a.nextGlance = now + 0.45f + Random.nextFloat() * 0.7f
        } else if (r < 0.25f) {                 // look straight again
            a.eyeTX = 0f
            a.eyeTY = 0f
            a.nextGlance = now + 0.8f + Random.nextFloat() * 2.5f
        } else if (r < 0.85f) {                 // glance somewhere
            a.eyeTX = Random.nextFloat() * 2f - 1f
            a.eyeTY = (Random.nextFloat() * 2f - 1f) * 0.5f
            a.nextGlance = now + 0.7f + Random.nextFloat() * 3.5f
        } else {                                // just stare for a while
            a.nextGlance = now + 2f + Random.nextFloat() * 4f
        }
    }
    val ek = 1f - exp(-dt * 16f)
    a.eyeX += (a.eyeTX - a.eyeX) * ek
    a.eyeY += (a.eyeTY - a.eyeY) * ek

    // ── random blinks (sometimes a quick double blink, sometimes a long pause)
    if (now >= a.nextBlink) {
        a.blinkStart = now
        a.nextBlink = if (Random.nextFloat() < 0.2f) now + 0.3f else now + 1.2f + Random.nextFloat() * 5f
    }

    // ── tiny random head wobble
    if (now >= a.nextMicro) {
        a.microTarget = (Random.nextFloat() * 2f - 1f) * 5f
        a.nextMicro = now + 1.2f + Random.nextFloat() * 3f
    }
    a.micro += (a.microTarget - a.micro) * (1f - exp(-dt * 2.5f))

    // ── pick what to do
    if (rig.sleepyUser) {
        if (a.act != Act.SLEEP) beginAct(a, Act.SLEEP, now, 600f)
        a.userSleep = true
    } else if (a.userSleep) {
        a.userSleep = false
        beginAct(a, Act.IDLE, now, 0.6f)
    } else if (rig.happy && a.act == Act.IDLE && now > a.happyCooldown) {
        beginAct(a, listOf(Act.DANCE, Act.KISS, Act.WAVE, Act.JUMP).random(), now)
        a.happyCooldown = now + 4f
    } else if (now >= a.actEnd) {
        if (a.act != Act.IDLE) beginAct(a, Act.IDLE, now, 1.2f + Random.nextFloat() * 1.8f)
        else beginAct(a, pickAct(a), now)
    }
}

private fun computePose(a: Anim, rig: Rig, now: Float): Pz {
    val z = a.pz
    z.blink = 0f; z.mouth = 0f; z.smile = 0f; z.earW = 0f
    z.armL = 0f; z.armR = 0f; z.tilt = 0f; z.tail = 0f
    z.lookX = 0f; z.lookY = 0f; z.hop = 0f; z.sway = 0f
    z.sleepy = false; z.scared = 0f; z.treat = null; z.treatScale = 1f
    z.hearts = false; z.zzz = false; z.notes = false

    val e = now - a.actStart
    val dur = max(a.actEnd - a.actStart, 0.01f)
    val p = (e / dur).coerceIn(0f, 1f)
    val env = minOf(1f, minOf(e, dur - e).coerceAtLeast(0f) * 4f)
    val pi = PI.toFloat()

    z.squash = 1f + 0.012f * sin(now * 2.2f + a.spot)
    z.tail = sin(now * 3f + a.spot) * 6f

    // blink (timing is random, decided in updateAnim)
    val bt = (now - a.blinkStart) / 0.16f
    if (bt in 0f..1f) z.blink = bell(bt)

    when (a.act) {
        Act.IDLE -> Unit
        Act.WAVE -> {
            z.armR = (140f + sin(e * 14f) * 18f) * env
            z.smile = 0.8f
            z.tilt = 4f * sin(e * 3f)
        }
        Act.YAWN -> {
            z.mouth = env
            z.blink = env
            z.tilt = -5f * env
            z.armL = 20f * env; z.armR = 20f * env
        }
        Act.LOOK -> z.tilt = a.eyeX * 7f
        Act.SLEEP -> {
            z.sleepy = true
            z.tilt = 9f
            z.zzz = true
            z.zzzT = now
            z.squash += 0.01f * sin(now * 1.4f)
        }
        Act.EAT -> {
            z.treat = a.sp.treat
            z.treatScale = 1f - p * 0.85f
            z.mouth = kotlin.math.abs(sin(e * 10f)) * 0.7f
            z.armL = 55f; z.armR = 55f
            z.tilt = 3f * sin(e * 10f)
        }
        Act.DANCE -> {
            z.sway = sin(e * 8f) * 0.07f
            z.hop = kotlin.math.abs(sin(e * 8f)) * 0.07f
            z.armL = 80f + 60f * sin(e * 8f)
            z.armR = 80f + 60f * sin(e * 8f + pi)
            z.tilt = sin(e * 8f) * 10f
            z.smile = 1f
            z.notes = true
            z.notesT = now
            z.tail = sin(e * 16f) * 20f
        }
        Act.KISS -> {
            z.smile = 1f
            z.mouth = 0.15f
            z.hearts = true
            z.heartT = e
            z.tilt = 6f * sin(e * 3f)
        }
        Act.EARS -> z.earW = sin(e * 28f) * 16f * env
        Act.JUMP -> {
            val s = kotlin.math.abs(sin(p * pi * 2f))
            z.hop = s * 0.28f
            z.squash = 1f - 0.18f * (1f - s) * (1f - s) * (1f - s)
            z.armL = 90f; z.armR = 90f
            z.smile = 1f
        }
    }

    // eyes + tiny head wobble + seated dangling legs
    z.lookX = a.eyeX
    z.lookY = a.eyeY
    z.tilt += a.micro + a.eyeX * 2f
    z.sit = true
    val lp = a.spot * 1.7f
    val kick = if (a.act == Act.DANCE || a.act == Act.JUMP) 22f else 0f
    z.legL = 6f * sin(now * 1.7f + lp) + 3f * sin(now * 3.1f + lp * 2f) + kick * sin(now * 9f)
    z.legR = 6f * sin(now * 1.3f + lp + 1f) + 3f * sin(now * 2.7f + lp) - kick * sin(now * 9f)

    // being boop-ed
    val bp = now - a.boop
    if (bp in 0f..1.6f) {
        z.hearts = true
        z.heartT = bp
        z.smile = 1f
        z.hop = max(z.hop, kotlin.math.abs(sin(bp * pi * 2.5f)) * 0.14f * (1f - bp / 1.6f))
    }

    // user is smiling -> animal is happy too
    if (rig.happy && a.act != Act.SLEEP) z.smile = max(z.smile, 0.8f)

    // head lags behind body rotation (feels alive)
    z.tilt += ((a.trot - a.rot) * 0.35f).coerceIn(-14f, 14f)

    // person moves fast -> hold on tight!
    if (a.jiggle > 0.22f && a.act != Act.SLEEP) {
        z.scared = ((a.jiggle - 0.22f) * 4f).coerceIn(0f, 1f)
        z.armL = max(z.armL, 75f * z.scared)
        z.armR = max(z.armR, 75f * z.scared)
        z.smile = 0f
    }
    return z
}

// ─────────────────────────────────────────────────────────────────────────────
@ExperimentalGetImage
@Composable
fun PetBuddiesScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // ── permission ───────────────────────────────────────────────────────────
    fun granted() = ContextCompat.checkSelfPermission(
        context, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    var cameraGranted by remember { mutableStateOf(granted()) }
    var asked by rememberSaveable { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        cameraGranted = granted()
    }
    LaunchedEffect(Unit) {
        if (!cameraGranted && !asked) {
            asked = true
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }
    if (!cameraGranted) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Camera permission is required for Pet Buddies", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text("Grant permission") }
            TextButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                    })
            }) { Text("Open Settings") }
        }
        return
    }

    // ── state ────────────────────────────────────────────────────────────────
    var isFront by rememberSaveable { mutableStateOf(true) }
    var headOn by rememberSaveable { mutableStateOf(true) }
    var glassesOn by rememberSaveable { mutableStateOf(true) }
    var shouldersOn by rememberSaveable { mutableStateOf(true) }
    var frameOn by rememberSaveable { mutableStateOf(true) }   // virtual glasses frame

    var canvasW by remember { mutableFloatStateOf(1080f) }
    var canvasH by remember { mutableFloatStateOf(1920f) }
    var tick by remember { mutableIntStateOf(0) }
    var faceCount by remember { mutableIntStateOf(0) }
    var capturing by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf(false) }
    var rootBounds by remember { mutableStateOf(Rect.Zero) }

    val rigs = remember { mutableMapOf<Int, Rig>() }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    val faceDetector = remember {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .enableTracking()
                .setMinFaceSize(0.12f)
                .build()
        )
    }
    val poseDetector = remember {
        PoseDetection.getClient(
            PoseDetectorOptions.Builder()
                .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
                .build()
        )
    }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            faceDetector.close()
            poseDetector.close()
            executor.shutdown()
        }
    }

    // ── detections -> anchors (MAIN thread) ──────────────────────────────────
    fun onFrame(faces: List<Face>, pose: Pose?, iw: Int, ih: Int) {
        val now = SystemClock.uptimeMillis() / 1000f
        val aw = iw.toFloat()
        val ah = ih.toFloat()
        val sc = maxOf(canvasW / aw, canvasH / ah)
        val offX = (aw * sc - canvasW) / 2f
        val offY = (ah * sc - canvasH) / 2f
        fun mp(x: Float, y: Float): Offset {
            val xx = if (isFront) aw - x else x
            return Offset(xx * sc - offX, y * sc - offY)
        }

        val list = faces.sortedByDescending { it.boundingBox.width() }.take(3)
        faceCount = list.size

        list.forEachIndexed { idx, face ->
            val id = face.trackingId ?: idx
            val rig = rigs.getOrPut(id) {
                Rig(id, now).also { assignSpecies(it, now) }
            }
            rig.lastSeen = now

            val box = face.boundingBox
            val ctr = mp(box.exactCenterX(), box.exactCenterY())
            val fw = box.width() * sc
            val fh = box.height() * sc

            // head roll as seen on screen (mirror flips the sign)
            val rot = if (isFront) face.headEulerAngleZ else -face.headEulerAngleZ
            val rr = rot * (PI.toFloat() / 180f)
            val upx = sin(rr)
            val upy = -cos(rr)
            val rx = cos(rr)
            val ry = sin(rr)

            // expressions
            rig.happy = (face.smilingProbability ?: 0f) > 0.65f
            val le = face.leftEyeOpenProbability ?: 1f
            val re = face.rightEyeOpenProbability ?: 1f
            if (le < 0.25f && re < 0.25f) {
                if (rig.eyesClosedSince < 0f) rig.eyesClosedSince = now
            } else rig.eyesClosedSince = -1f
            rig.sleepyUser = rig.eyesClosedSince >= 0f && now - rig.eyesClosedSince > 1.2f

            // ── HEAD (sits on top of the head)
            val head = rig.anims[SPOT_HEAD]
            head.tx = ctr.x + upx * fh * 0.47f
            head.ty = ctr.y + upy * fh * 0.47f
            head.trot = rot
            head.tsize = fw * 0.95f

            // ── GLASSES (perched on top rim of one lens)
            val pa = face.getLandmark(FaceLandmark.LEFT_EYE)?.position
            val pb = face.getLandmark(FaceLandmark.RIGHT_EYE)?.position
            val e1 = if (pa != null) mp(pa.x, pa.y)
            else Offset(ctr.x - rx * fw * 0.22f + upx * fh * 0.10f, ctr.y - ry * fw * 0.22f + upy * fh * 0.10f)
            val e2 = if (pb != null) mp(pb.x, pb.y)
            else Offset(ctr.x + rx * fw * 0.22f + upx * fh * 0.10f, ctr.y + ry * fw * 0.22f + upy * fh * 0.10f)
            val eyeA = if (e1.x <= e2.x) e1 else e2
            val eyeB = if (e1.x <= e2.x) e2 else e1
            val d = hypot(eyeB.x - eyeA.x, eyeB.y - eyeA.y).coerceAtLeast(10f)
            val lr = d * 0.46f
            rig.eyeA = eyeA; rig.eyeB = eyeB; rig.lens = lr; rig.rot = rot; rig.hasEyes = true

            val gl = rig.anims[SPOT_GLASSES]
            gl.tx = eyeB.x + upx * lr * 0.98f
            gl.ty = eyeB.y + upy * lr * 0.98f
            gl.trot = rot * 0.9f
            gl.tsize = d * 0.72f

            // ── SHOULDERS (real pose for the main person, estimate otherwise)
            var pL: Offset? = null
            var pR: Offset? = null
            if (idx == 0 && pose != null) {
                val l = pose.getPoseLandmark(PoseLandmark.LEFT_SHOULDER)
                val r = pose.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER)
                if (l != null && r != null && l.inFrameLikelihood > 0.5f && r.inFrameLikelihood > 0.5f) {
                    val a = mp(l.position.x, l.position.y)
                    val b = mp(r.position.x, r.position.y)
                    if (a.x <= b.x) { pL = a; pR = b } else { pL = b; pR = a }
                }
            }
            val shoulderY = ctr.y + fh * 1.08f
            val sL = pL ?: Offset(ctr.x - fw * 1.05f, shoulderY)
            val sR = pR ?: Offset(ctr.x + fw * 1.05f, shoulderY)
            val slope = atan2(sR.y - sL.y, sR.x - sL.x) * 180f / PI.toFloat() * 0.5f
            val ss = fw * 0.70f
            val shL = rig.anims[SPOT_SH_L]
            shL.tx = sL.x + (ctr.x - sL.x) * 0.20f
            shL.ty = sL.y - ss * 0.06f
            shL.trot = slope + 6f           // leans towards the neck
            shL.tsize = ss
            val shR = rig.anims[SPOT_SH_R]
            shR.tx = sR.x + (ctr.x - sR.x) * 0.20f
            shR.ty = sR.y - ss * 0.06f
            shR.trot = slope - 6f
            shR.tsize = ss
        }
    }
    val onFrameState = rememberUpdatedState<(List<Face>, Pose?, Int, Int) -> Unit>(
        newValue = { f, p, w, h -> onFrame(f, p, w, h) }
    )

    // ── animation clock ──────────────────────────────────────────────────────
    LaunchedEffect(Unit) {
        var last = -1L
        while (true) {
            withFrameNanos { n ->
                if (last < 0) last = n
                val dt = ((n - last) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                last = n
                val now = SystemClock.uptimeMillis() / 1000f
                val it = rigs.values.iterator()
                while (it.hasNext()) {
                    val rig = it.next()
                    if (now - rig.lastSeen > 1.0f) {
                        it.remove()
                        continue
                    }
                    if (now - rig.lastSeen < 0.3f) rig.anims.forEach { a -> updateAnim(a, rig, now, dt) }
                }
                tick++
            }
        }
    }

    // ── camera ───────────────────────────────────────────────────────────────
    DisposableEffect(lifecycleOwner, isFront) {
        rigs.clear()
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            val p = future.get()
            provider = p
            p.unbindAll()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { proxy: ImageProxy ->
                val media = proxy.image
                if (media == null) {
                    proxy.close()
                    return@setAnalyzer
                }
                val rot = proxy.imageInfo.rotationDegrees
                val iw = if (rot == 90 || rot == 270) proxy.height else proxy.width
                val ih = if (rot == 90 || rot == 270) proxy.width else proxy.height
                val input = InputImage.fromMediaImage(media, rot)
                val faceTask = faceDetector.process(input)
                val poseTask = if (shouldersOn) poseDetector.process(input) else null
                val all = if (poseTask != null) Tasks.whenAllComplete(faceTask, poseTask)
                else Tasks.whenAllComplete(faceTask)
                all.addOnCompleteListener(ContextCompat.getMainExecutor(context)) {
                    try {
                        val faces = if (faceTask.isSuccessful) faceTask.result else emptyList<Face>()
                        val pose = if (poseTask != null && poseTask.isSuccessful) poseTask.result else null
                        onFrameState.value(faces, pose, iw, ih)
                    } catch (_: Exception) {
                    } finally {
                        proxy.close()
                    }
                }
            }
            try {
                val sel = if (isFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                p.bindToLifecycle(lifecycleOwner, sel, preview, analysis)
            } catch (e: Exception) {
                Toast.makeText(context, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose { provider?.unbindAll() }
    }

    // ── actions ──────────────────────────────────────────────────────────────
    fun shuffleAll() {
        val now = SystemClock.uptimeMillis() / 1000f
        rigs.values.forEach { assignSpecies(it, now) }
    }

    fun boopAt(p: Offset) {
        val now = SystemClock.uptimeMillis() / 1000f
        var best: Anim? = null
        var bestD = Float.MAX_VALUE
        for (rig in rigs.values) {
            for (a in rig.anims) {
                val on = when (a.spot) {
                    SPOT_HEAD -> headOn
                    SPOT_GLASSES -> glassesOn
                    else -> shouldersOn
                }
                if (!on) continue
                val cx = a.x
                val cy = a.y - a.size * 0.5f
                val d = hypot(p.x - cx, p.y - cy)
                if (d < a.size * 0.6f && d < bestD) {
                    best = a
                    bestD = d
                }
            }
        }
        best?.let {
            it.boop = now
            if (it.act == Act.SLEEP) beginAct(it, Act.IDLE, now, 0.5f)
            else beginAct(it, if (Random.nextBoolean()) Act.JUMP else Act.KISS, now)
        }
    }

    fun takePhoto() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Toast.makeText(context, "Photo needs Android 8+", Toast.LENGTH_SHORT).show()
            return
        }
        val act = context.findActivity() ?: return
        scope.launch {
            capturing = true
            delay(180)
            val w = rootBounds.width.toInt().coerceAtLeast(1)
            val h = rootBounds.height.toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val src = android.graphics.Rect(
                rootBounds.left.toInt().coerceAtLeast(0),
                rootBounds.top.toInt().coerceAtLeast(0),
                rootBounds.right.toInt(),
                rootBounds.bottom.toInt()
            )
            val ok = try {
                suspendCoroutine<Boolean> { cont ->
                    PixelCopy.request(act.window, src, bmp, { res -> cont.resume(res == PixelCopy.SUCCESS) }, mainHandler)
                }
            } catch (e: Exception) {
                false
            }
            capturing = false
            if (!ok) {
                Toast.makeText(context, "Couldn't capture photo", Toast.LENGTH_SHORT).show()
                return@launch
            }
            flash = true
            val saved = withContext(Dispatchers.IO) {
                try {
                    val name = "PetBuddies_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/SmartClassifier")
                        }
                    }
                    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                        true
                    } else false
                } catch (e: Exception) {
                    false
                }
            }
            Toast.makeText(
                context,
                if (saved) "📸 Saved to Pictures/SmartClassifier" else "Couldn't save photo",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    LaunchedEffect(flash) {
        if (flash) {
            delay(160)
            flash = false
        }
    }
    val flashAlpha by animateFloatAsState(if (flash) 0.8f else 0f, label = "flash")

    // ── UI ───────────────────────────────────────────────────────────────────
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged {
                canvasW = it.width.toFloat()
                canvasH = it.height.toFloat()
            }
            .onGloballyPositioned { rootBounds = it.boundsInWindow() }
    ) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { off -> boopAt(off) }
                }
        ) {
            @Suppress("UNUSED_VARIABLE") val redraw = tick
            val now = SystemClock.uptimeMillis() / 1000f

            for (rig in rigs.values) {
                val away = ((now - rig.lastSeen - 0.35f) / 0.5f).coerceIn(0f, 1f)
                if (away >= 1f) continue

                // order: shoulders, head, glasses (+frame)
                for (spot in intArrayOf(SPOT_SH_L, SPOT_SH_R, SPOT_HEAD)) {
                    val on = if (spot == SPOT_HEAD) headOn else shouldersOn
                    if (on) drawOne(rig.anims[spot], rig, now, away)
                }
                if (rig.hasEyes && glassesOn && frameOn) drawGlassesFrame(rig, 1f - away)
                if (glassesOn) drawOne(rig.anims[SPOT_GLASSES], rig, now, away)
            }
        }

        if (!capturing) {
            // top bar
            Column(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(shape = RoundedCornerShape(50), color = Color.Black.copy(alpha = 0.55f)) {
                    Text(
                        if (faceCount == 0) "👤 Show your face – animals will hop on! (tap them 😉)"
                        else "🐾 $faceCount ${if (faceCount == 1) "person" else "people"} • tap an animal to boop it",
                        color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SpotChip("🎩 Head", headOn) { headOn = !headOn }
                    SpotChip("👓 Glasses", glassesOn) { glassesOn = !glassesOn }
                    SpotChip("🫂 Shoulders", shouldersOn) { shouldersOn = !shouldersOn }
                }
                if (glassesOn) {
                    SpotChip(if (frameOn) "🕶 Virtual glasses: ON" else "🕶 Virtual glasses: OFF", frameOn) { frameOn = !frameOn }
                }
            }

            // bottom bar
            Row(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 22.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundBtn("🎲", 56) { shuffleAll() }
                RoundBtn("📸", 72) { takePhoto() }
                RoundBtn("🔄", 56) { isFront = !isFront }
            }
        }

        if (flashAlpha > 0f) {
            Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flashAlpha)))
        }
    }
}

@Composable
private fun SpotChip(label: String, on: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (on) Color.Black else Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .background(if (on) Color(0xFFFFC107) else Color.Black.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun RoundBtn(emoji: String, dp: Int, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(dp.dp)
            .background(Color.Black.copy(alpha = 0.55f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(emoji, fontSize = (dp * 0.45f).sp)
    }
}

// ── drawing helpers ──────────────────────────────────────────────────────────
private fun DrawScope.drawOne(a: Anim, rig: Rig, now: Float, away: Float) {
    if (!a.init) return
    val pop = easeOutBack((now - a.born - SPOT_DELAY[a.spot]) / 0.55f)
    val s = a.size * pop * (1f - away)
    if (s < 2f) return
    val z = computePose(a, rig, now)
    withTransform({
        translate(a.x, a.y)
        rotate(a.rot, Offset.Zero)
        scale(s, s, Offset.Zero)
    }) {
        drawAnimal(a.sp, z)
    }
}

private fun DrawScope.drawGlassesFrame(rig: Rig, alpha: Float) {
    val lr = rig.lens
    val frame = Color(0xFF263238).copy(alpha = 0.9f * alpha)
    val w = lr * 0.14f
    for (c in arrayOf(rig.eyeA, rig.eyeB)) {
        drawCircle(Color.White.copy(alpha = 0.10f * alpha), lr, c)
        drawCircle(frame, lr, c, style = Stroke(w))
        drawCircle(Color.White.copy(alpha = 0.35f * alpha), lr * 0.18f, Offset(c.x - lr * 0.4f, c.y - lr * 0.4f))
    }
    // bridge
    val dir = Offset(rig.eyeB.x - rig.eyeA.x, rig.eyeB.y - rig.eyeA.y)
    val len = hypot(dir.x, dir.y).coerceAtLeast(1f)
    val ux = dir.x / len
    val uy = dir.y / len
    drawLine(
        frame,
        Offset(rig.eyeA.x + ux * lr, rig.eyeA.y + uy * lr),
        Offset(rig.eyeB.x - ux * lr, rig.eyeB.y - uy * lr),
        w, StrokeCap.Round
    )
    // temples
    drawLine(frame, Offset(rig.eyeA.x - ux * lr, rig.eyeA.y - uy * lr), Offset(rig.eyeA.x - ux * lr * 1.9f, rig.eyeA.y - uy * lr * 1.9f), w, StrokeCap.Round)
    drawLine(frame, Offset(rig.eyeB.x + ux * lr, rig.eyeB.y + uy * lr), Offset(rig.eyeB.x + ux * lr * 1.9f, rig.eyeB.y + uy * lr * 1.9f), w, StrokeCap.Round)
}
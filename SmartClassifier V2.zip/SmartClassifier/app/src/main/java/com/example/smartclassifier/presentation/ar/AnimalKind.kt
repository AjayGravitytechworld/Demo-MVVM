package com.example.smartclassifier.presentation.ar

import android.graphics.Paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

// ═════════════════════════════════════════════════════════════════════════════
//  Cute procedural animals.
//  Unit space: origin = bottom-centre of the sitting animal, y negative = up,
//  total height ≈ 1.0. The caller scales/rotates/translates it onto the person.
// ═════════════════════════════════════════════════════════════════════════════

enum class AnimalKind { CAT, DOG, BUNNY, PANDA, DUCK, PENGUIN, FOX, BEAR, OWL, PIG }

class Species(
    val name: String,
    val kind: AnimalKind,
    val body: Color,
    val belly: Color,
    val accent: Color,
    val dark: Color,
    val treat: String
)

private fun ac(rgb: Long) = Color(0xFF000000L or rgb)

val SPECIES: List<Species> = listOf(
    Species("Cat", AnimalKind.CAT, ac(0xF5A25D), ac(0xFFE3C2), ac(0xF48FB1), ac(0x7A4A24), "🐟"),
    Species("Dog", AnimalKind.DOG, ac(0xC99A6B), ac(0xF3DCC0), ac(0x7A4E2B), ac(0x5B3A1E), "🦴"),
    Species("Bunny", AnimalKind.BUNNY, ac(0xF3EEF0), ac(0xFFFFFF), ac(0xF8A5C2), ac(0x9A8A92), "🥕"),
    Species("Panda", AnimalKind.PANDA, ac(0xFAFAFA), ac(0xFFFFFF), ac(0x2B2B2B), ac(0x2B2B2B), "🎋"),
    Species("Duckling", AnimalKind.DUCK, ac(0xFFE066), ac(0xFFF3B0), ac(0xFF9F1C), ac(0xB8860B), "🍞"),
    Species("Penguin", AnimalKind.PENGUIN, ac(0x34435E), ac(0xFFFFFF), ac(0xFF9F1C), ac(0x1B2536), "🐟"),
    Species("Fox", AnimalKind.FOX, ac(0xF08A3C), ac(0xFFF1E0), ac(0x3B2A20), ac(0x8A4A1B), "🍇"),
    Species("Bear", AnimalKind.BEAR, ac(0xA9744F), ac(0xE6C9A8), ac(0x6B4226), ac(0x5A3820), "🍯"),
    Species("Owl", AnimalKind.OWL, ac(0xB08968), ac(0xF1DEC9), ac(0xFFB703), ac(0x6F4E37), "🐛"),
    Species("Piglet", AnimalKind.PIG, ac(0xF7B2C4), ac(0xFAD0DC), ac(0xE57F9B), ac(0xB5546F), "🍎")
)

/** Animation parameters for one frame. */
class Pz {
    var blink = 0f        // 0 open .. 1 closed
    var mouth = 0f        // 0 closed .. 1 wide open
    var smile = 0f        // >0.5 => happy ^ ^ eyes
    var earW = 0f         // ear wiggle (deg)
    var armL = 0f         // arm raise (deg), 0 = hanging
    var armR = 0f
    var tilt = 0f         // head tilt (deg)
    var tail = 0f         // tail wag (deg)
    var lookX = 0f        // -1..1
    var lookY = 0f
    var hop = 0f          // units up
    var sway = 0f         // units sideways
    var squash = 1f
    var sleepy = false
    var scared = 0f       // 0..1 (hanging on for dear life)
    var treat: String? = null
    var treatScale = 1f
    var hearts = false
    var heartT = 0f
    var zzz = false
    var zzzT = 0f
    var notes = false
    var notesT = 0f
    var sit = true        // seated pose (legs dangle below the surface)
    var legL = 0f         // dangling leg swing (deg)
    var legR = 0f
}

private val txt = Paint().apply {
    isAntiAlias = true
    textAlign = Paint.Align.CENTER
}

private fun heartPath(cx: Float, cy: Float, s: Float): Path = Path().apply {
    moveTo(cx, cy + s * 0.9f)
    cubicTo(cx - s * 1.4f, cy + s * 0.1f, cx - s * 0.9f, cy - s * 0.9f, cx, cy - s * 0.3f)
    cubicTo(cx + s * 0.9f, cy - s * 0.9f, cx + s * 1.4f, cy + s * 0.1f, cx, cy + s * 0.9f)
    close()
}

fun DrawScope.drawAnimal(sp: Species, z: Pz) {
    // ground shadow (only when standing)
    if (!z.sit) drawOval(Color.Black.copy(alpha = 0.15f), Offset(-0.30f, -0.025f), Size(0.60f, 0.07f))

    withTransform({
        translate(0f, -z.hop)
        scale(1f + (1f - z.squash) * 0.5f, z.squash, Offset.Zero)
    }) {
        drawTail(sp, z)
        drawBody(sp, z)
        drawHead(sp, z)
        drawOverlays(sp, z)
    }
}

// ── tail ─────────────────────────────────────────────────────────────────────
private fun DrawScope.drawThick(p: Path, color: Color, outline: Color, w: Float) {
    drawPath(p, outline, style = Stroke(w + 0.03f, cap = StrokeCap.Round))
    drawPath(p, color, style = Stroke(w, cap = StrokeCap.Round))
}

private fun DrawScope.drawTail(sp: Species, z: Pz) {
    val pv = Offset(0.20f, -0.10f)
    val line = sp.dark.copy(alpha = 0.8f)
    rotate(z.tail, pv) {
        when (sp.kind) {
            AnimalKind.CAT -> {
                val p = Path().apply {
                    moveTo(0.20f, -0.10f)
                    cubicTo(0.50f, -0.08f, 0.56f, -0.38f, 0.38f, -0.46f)
                }
                drawThick(p, sp.body, line, 0.075f)
            }
            AnimalKind.DOG -> {
                val p = Path().apply {
                    moveTo(0.20f, -0.12f)
                    quadraticBezierTo(0.40f, -0.14f, 0.42f, -0.32f)
                }
                drawThick(p, sp.body, line, 0.07f)
            }
            AnimalKind.FOX -> {
                rotate(-25f, Offset(0.26f, -0.12f)) {
                    drawOval(sp.body, Offset(0.22f, -0.28f), Size(0.40f, 0.20f))
                    drawOval(line, Offset(0.22f, -0.28f), Size(0.40f, 0.20f), style = Stroke(0.014f))
                    drawCircle(Color.White, 0.075f, Offset(0.57f, -0.18f))
                }
            }
            AnimalKind.BUNNY, AnimalKind.BEAR, AnimalKind.PANDA -> {
                drawCircle(if (sp.kind == AnimalKind.BEAR) sp.body else Color.White, 0.075f, Offset(0.21f, -0.10f))
                drawCircle(line, 0.075f, Offset(0.21f, -0.10f), style = Stroke(0.012f))
            }
            AnimalKind.PIG -> {
                val p = Path().apply {
                    moveTo(0.22f, -0.14f)
                    cubicTo(0.34f, -0.22f, 0.28f, -0.30f, 0.36f, -0.28f)
                }
                drawPath(p, line, style = Stroke(0.02f, cap = StrokeCap.Round))
            }
            AnimalKind.DUCK -> {
                val t = Path().apply {
                    moveTo(0.20f, -0.14f); lineTo(0.36f, -0.22f); lineTo(0.22f, -0.06f); close()
                }
                drawPath(t, sp.body)
                drawPath(t, line, style = Stroke(0.012f))
            }
            else -> Unit
        }
    }
}

// ── body, legs, arms ────────────────────────────────────────────────────────
private fun DrawScope.drawBody(sp: Species, z: Pz) {
    val line = sp.dark.copy(alpha = 0.8f)
    val lw = 0.014f
    val foot = when (sp.kind) {
        AnimalKind.PANDA, AnimalKind.PENGUIN, AnimalKind.DUCK -> sp.accent
        else -> lerp(sp.body, sp.dark, 0.35f)
    }
    val limb = when (sp.kind) {
        AnimalKind.PANDA -> sp.accent
        else -> sp.body
    }

    if (z.sit) {
        // ── SEATED: pear-shaped body, flat bottom on the surface, legs dangling below it
        val tl = Offset(-0.29f, -0.43f)
        val sz = Size(0.58f, 0.43f)
        drawOval(sp.body, tl, sz)
        when (sp.kind) {
            AnimalKind.PENGUIN -> drawOval(sp.belly, Offset(-0.21f, -0.40f), Size(0.42f, 0.36f))
            AnimalKind.PANDA -> Unit
            else -> drawOval(sp.belly, Offset(-0.16f, -0.35f), Size(0.32f, 0.26f))
        }
        drawOval(line, tl, sz, style = Stroke(lw))

        val swing = floatArrayOf(z.legL, z.legR)
        val sides = floatArrayOf(-1f, 1f)
        for (i in 0 until 2) {
            val s = sides[i]
            val hip = Offset(s * 0.19f, -0.07f)
            // thigh (resting on the surface)
            rotate(s * -14f, hip) {
                drawOval(limb, Offset(s * 0.19f - 0.115f, -0.15f), Size(0.23f, 0.15f))
                drawOval(line, Offset(s * 0.19f - 0.115f, -0.15f), Size(0.23f, 0.15f), style = Stroke(lw * 0.8f))
            }
            // lower leg + foot hanging down and swinging
            rotate(swing[i], hip) {
                drawOval(limb, Offset(s * 0.19f - 0.055f, -0.08f), Size(0.11f, 0.19f))
                drawOval(line, Offset(s * 0.19f - 0.055f, -0.08f), Size(0.11f, 0.19f), style = Stroke(lw * 0.8f))
                drawOval(foot, Offset(s * 0.19f - 0.08f, 0.06f), Size(0.16f, 0.095f))
                drawOval(line, Offset(s * 0.19f - 0.08f, 0.06f), Size(0.16f, 0.095f), style = Stroke(lw * 0.8f))
            }
        }
    } else {
        // ── STANDING
        val bodyTL = Offset(-0.27f, -0.45f)
        val bodySz = Size(0.54f, 0.45f)
        drawOval(sp.body, bodyTL, bodySz)
        when (sp.kind) {
            AnimalKind.PENGUIN -> drawOval(sp.belly, Offset(-0.20f, -0.42f), Size(0.40f, 0.38f))
            AnimalKind.PANDA -> Unit
            else -> drawOval(sp.belly, Offset(-0.15f, -0.36f), Size(0.30f, 0.27f))
        }
        drawOval(line, bodyTL, bodySz, style = Stroke(lw))
        for (x in floatArrayOf(-0.23f, 0.06f)) {
            drawOval(foot, Offset(x, -0.07f), Size(0.17f, 0.09f))
            drawOval(line, Offset(x, -0.07f), Size(0.17f, 0.09f), style = Stroke(lw * 0.8f))
        }
    }

    // ── arms (positive raise swings outward/up)
    val armColor = if (sp.kind == AnimalKind.PANDA) sp.accent else sp.body
    val armY = if (z.sit) -0.34f else -0.36f
    rotate(-(12f + z.armR), Offset(0.25f, armY)) {
        drawOval(armColor, Offset(0.195f, armY), Size(0.11f, 0.20f))
        drawOval(line, Offset(0.195f, armY), Size(0.11f, 0.20f), style = Stroke(lw * 0.8f))
    }
    rotate(12f + z.armL, Offset(-0.25f, armY)) {
        drawOval(armColor, Offset(-0.305f, armY), Size(0.11f, 0.20f))
        drawOval(line, Offset(-0.305f, armY), Size(0.11f, 0.20f), style = Stroke(lw * 0.8f))
    }
}

// ── head ─────────────────────────────────────────────────────────────────────
private fun DrawScope.drawHead(sp: Species, z: Pz) {
    val r = 0.30f
    val line = sp.dark.copy(alpha = 0.8f)
    val lw = 0.014f
    val pupil = Color(0xFF1B1B1B)

    withTransform({
        translate(z.sway * 0.3f, -0.60f)
        rotate(z.tilt, Offset.Zero)
    }) {
        // ── ears (behind the head circle)
        for (s in floatArrayOf(-1f, 1f)) {
            when (sp.kind) {
                AnimalKind.CAT, AnimalKind.FOX -> rotate(s * z.earW, Offset(s * 0.17f, -0.22f)) {
                    val outer = Path().apply {
                        moveTo(s * 0.29f, -0.08f); lineTo(s * 0.07f, -0.27f); lineTo(s * 0.25f, -0.52f); close()
                    }
                    drawPath(outer, sp.body)
                    drawPath(outer, line, style = Stroke(lw))
                    val inner = Path().apply {
                        moveTo(s * 0.23f, -0.17f); lineTo(s * 0.11f, -0.27f); lineTo(s * 0.23f, -0.42f); close()
                    }
                    drawPath(inner, if (sp.kind == AnimalKind.CAT) sp.accent else sp.dark)
                }
                AnimalKind.PANDA, AnimalKind.BEAR -> rotate(s * z.earW * 0.5f, Offset(s * 0.2f, -0.2f)) {
                    drawCircle(if (sp.kind == AnimalKind.PANDA) sp.accent else sp.body, 0.11f, Offset(s * 0.22f, -0.23f))
                    drawCircle(line, 0.11f, Offset(s * 0.22f, -0.23f), style = Stroke(lw))
                    if (sp.kind == AnimalKind.BEAR) drawCircle(sp.belly, 0.06f, Offset(s * 0.22f, -0.23f))
                }
                AnimalKind.BUNNY -> rotate(s * (7f + z.earW * 0.5f), Offset(s * 0.12f, -0.26f)) {
                    drawOval(sp.body, Offset(s * 0.12f - 0.075f, -0.78f), Size(0.15f, 0.54f))
                    drawOval(line, Offset(s * 0.12f - 0.075f, -0.78f), Size(0.15f, 0.54f), style = Stroke(lw))
                    drawOval(sp.accent, Offset(s * 0.12f - 0.04f, -0.72f), Size(0.08f, 0.38f))
                }
                AnimalKind.DOG -> rotate(s * (-8f - z.earW * 0.5f), Offset(s * 0.24f, -0.16f)) {
                    drawOval(sp.accent, Offset(s * 0.29f - 0.085f, -0.14f), Size(0.17f, 0.32f))
                    drawOval(line, Offset(s * 0.29f - 0.085f, -0.14f), Size(0.17f, 0.32f), style = Stroke(lw))
                }
                AnimalKind.PIG -> rotate(s * z.earW * 0.5f, Offset(s * 0.2f, -0.2f)) {
                    val e = Path().apply {
                        moveTo(s * 0.27f, -0.10f); lineTo(s * 0.12f, -0.27f); lineTo(s * 0.33f, -0.33f); close()
                    }
                    drawPath(e, sp.body)
                    drawPath(e, line, style = Stroke(lw))
                }
                AnimalKind.OWL -> rotate(s * z.earW * 0.5f, Offset(s * 0.2f, -0.24f)) {
                    val e = Path().apply {
                        moveTo(s * 0.26f, -0.18f); lineTo(s * 0.10f, -0.28f); lineTo(s * 0.31f, -0.47f); close()
                    }
                    drawPath(e, sp.dark)
                }
                else -> Unit
            }
        }

        // ── head circle
        drawCircle(sp.body, r, Offset.Zero)
        drawCircle(line, r, Offset.Zero, style = Stroke(lw))

        // ── species face decoration
        when (sp.kind) {
            AnimalKind.PENGUIN -> drawOval(sp.belly, Offset(-0.21f, -0.10f), Size(0.42f, 0.32f))
            AnimalKind.PANDA -> for (s in floatArrayOf(-1f, 1f)) {
                rotate(s * -22f, Offset(s * 0.12f, -0.01f)) {
                    drawOval(sp.accent, Offset(s * 0.12f - 0.065f, -0.09f), Size(0.13f, 0.17f))
                }
            }
            AnimalKind.FOX -> for (s in floatArrayOf(-1f, 1f)) {
                rotate(s * -20f, Offset(s * 0.14f, 0.12f)) {
                    drawOval(Color.White, Offset(s * 0.14f - 0.12f, 0.05f), Size(0.24f, 0.15f))
                }
            }
            AnimalKind.DOG, AnimalKind.BEAR -> drawOval(sp.belly, Offset(-0.125f, 0.025f), Size(0.25f, 0.18f))
            AnimalKind.CAT -> for (x in floatArrayOf(-0.07f, 0f, 0.07f)) {
                drawLine(sp.dark.copy(alpha = 0.55f), Offset(x, -0.29f), Offset(x * 0.8f, -0.19f), 0.02f, StrokeCap.Round)
            }
            AnimalKind.OWL -> for (s in floatArrayOf(-1f, 1f)) {
                drawCircle(sp.belly, 0.135f, Offset(s * 0.125f, -0.03f))
                drawCircle(sp.dark.copy(alpha = 0.5f), 0.135f, Offset(s * 0.125f, -0.03f), style = Stroke(lw))
            }
            AnimalKind.DUCK -> {
                val tuft = Path().apply {
                    moveTo(0f, -0.29f); quadraticBezierTo(0.03f, -0.40f, 0.10f, -0.38f)
                }
                drawPath(tuft, sp.body, style = Stroke(0.035f, cap = StrokeCap.Round))
            }
            else -> Unit
        }

        // ── eyes
        val owl = sp.kind == AnimalKind.OWL
        val ex = if (owl) 0.125f else 0.115f
        val ey = if (owl) -0.03f else -0.02f
        for (s in floatArrayOf(-1f, 1f)) {
            val c = Offset(s * ex, ey)
            val closed = z.sleepy || z.blink > 0.85f
            when {
                closed -> {
                    val p = Path().apply {
                        moveTo(c.x - 0.04f, c.y)
                        quadraticBezierTo(c.x, c.y + 0.045f, c.x + 0.04f, c.y)
                    }
                    drawPath(p, pupil, style = Stroke(0.016f, cap = StrokeCap.Round))
                }
                z.smile > 0.5f -> {
                    val p = Path().apply {
                        moveTo(c.x - 0.042f, c.y + 0.012f)
                        quadraticBezierTo(c.x, c.y - 0.05f, c.x + 0.042f, c.y + 0.012f)
                    }
                    drawPath(p, pupil, style = Stroke(0.017f, cap = StrokeCap.Round))
                }
                owl -> {
                    drawCircle(Color.White, 0.095f, c)
                    drawCircle(pupil, 0.05f * (1f + z.scared * 0.3f), Offset(c.x + z.lookX * 0.03f, c.y + z.lookY * 0.02f))
                    drawCircle(Color.White, 0.016f, Offset(c.x + z.lookX * 0.03f - 0.012f, c.y + z.lookY * 0.02f - 0.014f))
                }
                else -> {
                    val rr = 0.054f * (1f + z.scared * 0.35f)
                    val ry = rr * (1f - z.blink * 0.9f)
                    val cx = c.x + z.lookX * 0.032f
                    val cy = c.y + z.lookY * 0.022f
                    drawOval(pupil, Offset(cx - rr, cy - ry), Size(rr * 2f, ry * 2f))
                    drawCircle(Color.White, rr * 0.36f, Offset(cx - rr * 0.28f, cy - ry * 0.38f))
                    drawCircle(Color.White, rr * 0.16f, Offset(cx + rr * 0.32f, cy + ry * 0.3f))
                }
            }
        }

        // ── blush
        if (sp.kind != AnimalKind.OWL && sp.kind != AnimalKind.PANDA) {
            for (s in floatArrayOf(-1f, 1f)) {
                drawCircle(Color(0xFFFF6F91).copy(alpha = 0.40f), 0.042f, Offset(s * 0.205f, 0.07f))
            }
        }

        // ── nose + mouth
        val mo = z.mouth
        fun openMouth(cx: Float, cy: Float, w: Float) {
            val h = 0.02f + 0.075f * mo
            drawOval(Color(0xFF5A1A22), Offset(cx - w / 2f, cy), Size(w, h))
            drawOval(Color(0xFFF48FB1), Offset(cx - w * 0.32f, cy + h * 0.45f), Size(w * 0.64f, h * 0.5f))
        }
        fun smileLine(cx: Float, cy: Float, w: Float) {
            val p = Path().apply {
                moveTo(cx - w, cy)
                quadraticBezierTo(cx, cy + w * 0.95f, cx + w, cy)
            }
            drawPath(p, sp.dark, style = Stroke(0.014f, cap = StrokeCap.Round))
        }

        when (sp.kind) {
            AnimalKind.CAT -> {
                val nose = Path().apply {
                    moveTo(-0.026f, 0.05f); lineTo(0.026f, 0.05f); lineTo(0f, 0.08f); close()
                }
                drawPath(nose, sp.accent)
                if (mo > 0.05f) openMouth(0f, 0.095f, 0.08f) else {
                    val m = Path().apply {
                        moveTo(0f, 0.08f); quadraticBezierTo(-0.03f, 0.13f, -0.07f, 0.095f)
                        moveTo(0f, 0.08f); quadraticBezierTo(0.03f, 0.13f, 0.07f, 0.095f)
                    }
                    drawPath(m, sp.dark, style = Stroke(0.013f, cap = StrokeCap.Round))
                }
                for (s in floatArrayOf(-1f, 1f)) for (k in 0 until 3) {
                    val y = 0.06f + k * 0.03f
                    drawLine(sp.dark.copy(alpha = 0.55f), Offset(s * 0.15f, y), Offset(s * 0.36f, y + (k - 1) * 0.03f), 0.008f, StrokeCap.Round)
                }
            }
            AnimalKind.DOG, AnimalKind.BEAR -> {
                drawOval(sp.dark, Offset(-0.045f, 0.035f), Size(0.09f, 0.06f))
                drawCircle(Color.White.copy(alpha = 0.6f), 0.009f, Offset(-0.015f, 0.05f))
                if (mo > 0.05f) openMouth(0f, 0.11f, 0.09f) else {
                    drawLine(sp.dark, Offset(0f, 0.095f), Offset(0f, 0.115f), 0.012f, StrokeCap.Round)
                    smileLine(-0.04f, 0.115f, 0.04f)
                    smileLine(0.04f, 0.115f, 0.04f)
                    if (z.smile > 0.5f && sp.kind == AnimalKind.DOG) {
                        drawOval(Color(0xFFF48FB1), Offset(-0.025f, 0.13f), Size(0.05f, 0.06f))
                    }
                }
            }
            AnimalKind.BUNNY -> {
                drawOval(sp.accent, Offset(-0.03f, 0.045f), Size(0.06f, 0.04f))
                if (mo > 0.05f) openMouth(0f, 0.10f, 0.07f) else {
                    drawLine(sp.dark, Offset(0f, 0.085f), Offset(0f, 0.10f), 0.011f, StrokeCap.Round)
                    smileLine(-0.03f, 0.10f, 0.03f)
                    smileLine(0.03f, 0.10f, 0.03f)
                    drawRect(Color.White, Offset(-0.024f, 0.105f), Size(0.048f, 0.045f))
                    drawRect(sp.dark.copy(alpha = 0.5f), Offset(-0.024f, 0.105f), Size(0.048f, 0.045f), style = Stroke(0.007f))
                }
            }
            AnimalKind.PANDA -> {
                drawOval(sp.accent, Offset(-0.04f, 0.045f), Size(0.08f, 0.055f))
                if (mo > 0.05f) openMouth(0f, 0.11f, 0.08f) else smileLine(0f, 0.11f, 0.04f)
            }
            AnimalKind.DUCK -> {
                drawOval(sp.accent, Offset(-0.115f, 0.035f), Size(0.23f, 0.10f))
                drawOval(sp.dark.copy(alpha = 0.6f), Offset(-0.115f, 0.035f), Size(0.23f, 0.10f), style = Stroke(0.01f))
                if (mo > 0.05f) drawOval(Color(0xFF5A1A22), Offset(-0.07f, 0.085f), Size(0.14f, 0.015f + 0.06f * mo))
            }
            AnimalKind.PENGUIN -> {
                val beak = Path().apply {
                    moveTo(-0.05f, 0.04f); lineTo(0.05f, 0.04f); lineTo(0f, 0.11f + 0.03f * mo); close()
                }
                drawPath(beak, sp.accent)
                drawPath(beak, sp.dark.copy(alpha = 0.6f), style = Stroke(0.01f))
            }
            AnimalKind.FOX -> {
                drawCircle(sp.accent, 0.03f, Offset(0f, 0.065f))
                if (mo > 0.05f) openMouth(0f, 0.10f, 0.08f) else {
                    drawLine(sp.dark, Offset(0f, 0.09f), Offset(0f, 0.11f), 0.011f, StrokeCap.Round)
                    smileLine(-0.035f, 0.11f, 0.035f)
                    smileLine(0.035f, 0.11f, 0.035f)
                }
            }
            AnimalKind.OWL -> {
                val beak = Path().apply {
                    moveTo(-0.032f, 0.045f); lineTo(0.032f, 0.045f); lineTo(0f, 0.105f + 0.03f * mo); close()
                }
                drawPath(beak, sp.accent)
                drawPath(beak, sp.dark.copy(alpha = 0.6f), style = Stroke(0.01f))
            }
            AnimalKind.PIG -> {
                drawOval(sp.accent, Offset(-0.10f, 0.035f), Size(0.20f, 0.14f))
                drawOval(sp.dark.copy(alpha = 0.6f), Offset(-0.10f, 0.035f), Size(0.20f, 0.14f), style = Stroke(0.01f))
                drawOval(sp.dark, Offset(-0.05f, 0.085f), Size(0.03f, 0.04f))
                drawOval(sp.dark, Offset(0.02f, 0.085f), Size(0.03f, 0.04f))
                if (mo > 0.05f) openMouth(0f, 0.15f, 0.08f)
            }
        }
    }
}

// ── things floating around / held ────────────────────────────────────────────
private fun DrawScope.drawOverlays(sp: Species, z: Pz) {
    val nc = drawContext.canvas.nativeCanvas

    // treat in paws
    z.treat?.let { tr ->
        txt.textSize = 0.17f * z.treatScale
        txt.color = android.graphics.Color.WHITE
        nc.drawText(tr, 0f, -0.20f + 0.05f * z.treatScale, txt)
    }

    // hearts
    if (z.hearts) {
        for (i in 0 until 4) {
            val ph = (z.heartT * 0.7f + i * 0.25f) % 1f
            val x = sin(i * 2.1f + ph * 4f) * 0.14f
            val y = -0.86f - ph * 0.45f
            drawPath(heartPath(x, y, 0.045f + 0.012f * i), Color(0xFFFF4081).copy(alpha = (1f - ph).coerceIn(0f, 1f)))
        }
    }

    // zzz
    if (z.zzz) {
        val letters = arrayOf("z", "Z", "Z")
        for (i in 0 until 3) {
            val ph = (z.zzzT * 0.5f + i * 0.33f) % 1f
            txt.textSize = 0.10f + 0.04f * i
            txt.color = android.graphics.Color.argb(((1f - ph) * 255).toInt().coerceIn(0, 255), 255, 255, 255)
            nc.drawText(letters[i], 0.26f + ph * 0.12f + i * 0.04f, -0.86f - ph * 0.30f, txt)
        }
    }

    // music notes
    if (z.notes) {
        val glyph = arrayOf("♪", "♫", "♪")
        for (i in 0 until 3) {
            val ph = (z.notesT * 0.6f + i * 0.33f) % 1f
            txt.textSize = 0.13f
            txt.color = android.graphics.Color.argb(((1f - ph) * 255).toInt().coerceIn(0, 255), 255, 235, 59)
            nc.drawText(glyph[i], (i - 1) * 0.2f + sin(ph * 6f + i) * 0.05f, -0.90f - ph * 0.35f, txt)
        }
    }
}

/** Soft elastic overshoot for pop-in. */
fun easeOutBack(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val t = x.coerceIn(0f, 1f) - 1f
    return 1f + c3 * t * t * t + c1 * t * t
}

fun bell(p: Float): Float = abs(sin(p.coerceIn(0f, 1f) * PI.toFloat()))
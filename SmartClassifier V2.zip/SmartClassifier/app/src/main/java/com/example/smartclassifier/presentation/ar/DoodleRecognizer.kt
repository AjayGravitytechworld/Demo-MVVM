package com.example.smartclassifier.presentation.ar

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.Ink
import kotlinx.coroutines.tasks.await

class DoodleRecognizer {

    private var recognizer: DigitalInkRecognizer? = null

    suspend fun recognize(strokes: List<List<InkPoint>>): List<String> {
        val usable = strokes.filter { it.size >= 2 }
        if (usable.isEmpty()) return emptyList()
        val client = client()

        val ink = Ink.builder()
        var lastT = 0L
        for (stroke in usable.sortedBy { it.first().t }) {
            val sb = Ink.Stroke.builder()
            for (p in stroke) {
                val t = if (p.t <= lastT) lastT + 1 else p.t
                lastT = t
                sb.addPoint(Ink.Point.create(p.x, p.y, t))
            }
            ink.addStroke(sb.build())
        }

        val result = client.recognize(ink.build()).await()
        return result.candidates.map { it.text.trim() }.filter { it.isNotBlank() }.distinct()
    }

    private suspend fun client(): DigitalInkRecognizer {
        recognizer?.let { return it }

        val id = DigitalInkRecognitionModelIdentifier.fromLanguageTag(TAG)
            ?: throw IllegalStateException("Doodle model not available")
        val model = DigitalInkRecognitionModel.builder(id).build()

        val manager = RemoteModelManager.getInstance()
        if (!manager.isModelDownloaded(model).await()) {
            manager.download(model, DownloadConditions.Builder().build()).await()
        }
        val c = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
        recognizer = c
        return c
    }

    fun close() {
        recognizer?.close()
        recognizer = null
    }

    companion object {
        private const val TAG = "zxx-Zsym-x-autodraw"
    }
}
package com.example.smartclassifier.presentation.ar

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// ═════════════════════════════════════════════════════════════════════════════
//  THEMES  (label from the AI  ->  how the doodle moves + its colours)
// ═════════════════════════════════════════════════════════════════════════════

enum class Motion { WALK, FLY, SWIM, SPIN, SWAY, DRIVE, FLOAT, BOUNCE, WOBBLE }
enum class Fx { NONE, BUBBLES, RAIN, SPARKLE, HEARTS, LEAVES, SPEED }
enum class Scene { GROUND, WATER, SKY, NIGHT }

class DoodleTheme(
    val key: String,
    val emoji: String,
    val motion: Motion,
    val palette: List<Color>,
    val fx: Fx,
    val scene: Scene
)

private fun c(rgb: Long) = Color(0xFF000000L or rgb)

private class Rule(val words: List<String>, val theme: DoodleTheme)

private val RULES: List<Rule> = listOf(
    Rule(
        listOf("cat", "kitten", "tiger", "lion"),
        DoodleTheme("cat", "🐱", Motion.WALK, listOf(c(0xFFB74D), c(0xFFE0B2), c(0xFF8A65), c(0x6D4C41)), Fx.HEARTS, Scene.GROUND)
    ),
    Rule(
        listOf(
            "dog", "puppy", "bear", "horse", "cow", "pig", "sheep", "rabbit", "bunny", "mouse", "elephant",
            "giraffe", "monkey", "fox", "panda", "zebra", "kangaroo", "camel", "donkey", "squirrel",
            "hedgehog", "dinosaur", "dragon", "unicorn", "animal", "snake", "frog"
        ),
        DoodleTheme("animal", "🐶", Motion.WALK, listOf(c(0xA1887F), c(0xD7CCC8), c(0x8D6E63), c(0xFFCC80)), Fx.SPARKLE, Scene.GROUND)
    ),
    Rule(
        listOf(
            "bird", "duck", "owl", "butterfly", "bee", "bat", "parrot", "airplane", "plane", "helicopter",
            "angel", "ladybug", "dragonfly", "ufo", "rocket", "eagle", "swan", "penguin"
        ),
        DoodleTheme("bird", "🐦", Motion.FLY, listOf(c(0x64B5F6), c(0xFFD54F), c(0xF06292), c(0x81C784)), Fx.SPARKLE, Scene.SKY)
    ),
    Rule(
        listOf(
            "fish", "whale", "dolphin", "shark", "octopus", "turtle", "crab", "jellyfish", "submarine",
            "boat", "sailboat", "ship", "seahorse", "starfish", "lobster", "shrimp"
        ),
        DoodleTheme("fish", "🐟", Motion.SWIM, listOf(c(0x29B6F6), c(0xFF8A65), c(0xFFEE58), c(0x4DD0E1)), Fx.BUBBLES, Scene.WATER)
    ),
    Rule(
        listOf("sun", "star", "clock", "compass"),
        DoodleTheme("sun", "☀️", Motion.SPIN, listOf(c(0xFFEB3B), c(0xFFB300), c(0xFF7043)), Fx.SPARKLE, Scene.SKY)
    ),
    Rule(
        listOf("flower", "wheel", "snowflake", "windmill", "fan", "pinwheel", "cookie", "donut", "pizza", "gear", "sunflower", "daisy"),
        DoodleTheme("flower", "🌸", Motion.SPIN, listOf(c(0xF06292), c(0xFFD54F), c(0xAB47BC), c(0x4DD0E1)), Fx.SPARKLE, Scene.SKY)
    ),
    Rule(
        listOf("tree", "plant", "grass", "cactus", "palm", "mushroom", "bush", "leaf", "broccoli"),
        DoodleTheme("tree", "🌳", Motion.SWAY, listOf(c(0x43A047), c(0x8D6E63), c(0x66BB6A), c(0xA5D6A7)), Fx.LEAVES, Scene.GROUND)
    ),
    Rule(
        listOf("car", "bus", "truck", "train", "bicycle", "bike", "motorcycle", "van", "ambulance", "tractor", "scooter", "skateboard", "police"),
        DoodleTheme("car", "🚗", Motion.DRIVE, listOf(c(0xEF5350), c(0x42A5F5), c(0xFFCA28), c(0x78909C)), Fx.SPEED, Scene.GROUND)
    ),
    Rule(
        listOf("cloud", "rain", "umbrella"),
        DoodleTheme("cloud", "☁️", Motion.FLOAT, listOf(c(0x90CAF9), c(0xECEFF1), c(0xB39DDB)), Fx.RAIN, Scene.SKY)
    ),
    Rule(
        listOf("moon", "night"),
        DoodleTheme("moon", "🌙", Motion.FLOAT, listOf(c(0xFFF59D), c(0xFFE082), c(0xB0BEC5)), Fx.SPARKLE, Scene.NIGHT)
    ),
    Rule(
        listOf("balloon", "kite", "parachute"),
        DoodleTheme("balloon", "🎈", Motion.FLOAT, listOf(c(0xEF5350), c(0xFFCA28), c(0x42A5F5), c(0x66BB6A)), Fx.SPARKLE, Scene.SKY)
    ),
    Rule(
        listOf("heart", "love"),
        DoodleTheme("heart", "❤️", Motion.BOUNCE, listOf(c(0xF06292), c(0xEC407A), c(0xFF80AB)), Fx.HEARTS, Scene.NIGHT)
    ),
    Rule(
        listOf("apple", "strawberry", "cherry", "tomato"),
        DoodleTheme("apple", "🍎", Motion.BOUNCE, listOf(c(0xE53935), c(0x43A047), c(0x8D6E63)), Fx.SPARKLE, Scene.GROUND)
    ),
    Rule(
        listOf("house", "home", "castle", "tent", "barn"),
        DoodleTheme("house", "🏠", Motion.BOUNCE, listOf(c(0xEF5350), c(0xFFCC80), c(0x8D6E63), c(0x42A5F5)), Fx.SPARKLE, Scene.GROUND)
    ),
    Rule(
        listOf("banana", "lemon", "pear", "orange", "egg", "cake", "cupcake", "ice cream", "candy", "gift", "present", "ball", "face", "smile"),
        DoodleTheme("fun", "🎉", Motion.BOUNCE, listOf(c(0xFF7043), c(0xFFCA28), c(0x66BB6A), c(0x42A5F5)), Fx.SPARKLE, Scene.GROUND)
    )
)

private val DEFAULT_THEME = DoodleTheme(
    "doodle", "✨", Motion.WOBBLE,
    listOf(c(0xEF5350), c(0xFFA726), c(0xFFEE58), c(0x66BB6A), c(0x42A5F5), c(0xAB47BC)),
    Fx.SPARKLE, Scene.NIGHT
)

fun themeFor(rawLabel: String?): DoodleTheme {
    val norm = (rawLabel ?: "").lowercase().replace('_', ' ').replace('-', ' ').trim()
    if (norm.isEmpty()) return DEFAULT_THEME
    val tokens = norm.split(' ')
    for (rule in RULES) {
        for (w in rule.words) {
            if (tokens.contains(w) || (w.length >= 5 && norm.contains(w))) return rule.theme
        }
    }
    return DEFAULT_THEME
}

// ═════════════════════════════════════════════════════════════════════════════
//  DOODLE MODEL  (user's strokes normalised, closed shapes / eyes detected)
// ═════════════════════════════════════════════════════════════════════════════

const val DOODLE_FIT = 1000f

class DoodleStroke(
    val pts: List<Offset>,   // centred, fitted into ~1000 units
    val uv: List<Offset>,    // 0..1 position inside the whole doodle
    val closed: Boolean,
    val eye: Boolean,        // tiny closed blob -> googly eye
    val rank: Int            // 0 = biggest shape -> body colour
)

class Doodle(val strokes: List<DoodleStroke>, val w: Float, val h: Float)

private class Tmp(
    val pts: List<Offset>,
    val uv: List<Offset>,
    val closed: Boolean,
    val eye: Boolean,
    val area: Float
)

fun buildDoodle(raw: List<List<Offset>>): Doodle? {
    val strokes = raw.filter { it.size >= 2 }
    if (strokes.isEmpty()) return null
    val all = strokes.flatten()
    val minX = all.minOf { it.x }
    val maxX = all.maxOf { it.x }
    val minY = all.minOf { it.y }
    val maxY = all.maxOf { it.y }
    val bw = max(maxX - minX, 1f)
    val bh = max(maxY - minY, 1f)
    val s = DOODLE_FIT / max(bw, bh)
    val cx = (minX + maxX) / 2f
    val cy = (minY + maxY) / 2f
    val docDiag = hypot(bw * s, bh * s)

    val tmp = strokes.map { st ->
        val pts = st.map { Offset((it.x - cx) * s, (it.y - cy) * s) }
        val uv = st.map { Offset((it.x - minX) / bw, (it.y - minY) / bh) }
        var len = 0f
        for (i in 1 until pts.size) len += (pts[i] - pts[i - 1]).getDistance()
        val closed = pts.size >= 6 && (pts.first() - pts.last()).getDistance() < 0.22f * len
        val w = pts.maxOf { it.x } - pts.minOf { it.x }
        val h = pts.maxOf { it.y } - pts.minOf { it.y }
        val eye = closed && hypot(w, h) < 0.16f * docDiag
        Tmp(pts, uv, closed, eye, w * h)
    }.sortedByDescending { it.area }

    return Doodle(
        strokes = tmp.mapIndexed { i, t -> DoodleStroke(t.pts, t.uv, t.closed, t.eye, i) },
        w = bw * s,
        h = bh * s
    )
}

fun doodleScale(size: Size): Float = min(size.width, size.height) * 0.38f / DOODLE_FIT

fun smoothPath(pts: List<Offset>, close: Boolean = false): Path {
    val p = Path()
    if (pts.isEmpty()) return p
    p.moveTo(pts[0].x, pts[0].y)
    if (pts.size == 1) return p
    if (pts.size == 2) {
        p.lineTo(pts[1].x, pts[1].y)
        return p
    }
    for (i in 1 until pts.size - 1) {
        val mx = (pts[i].x + pts[i + 1].x) / 2f
        val my = (pts[i].y + pts[i + 1].y) / 2f
        p.quadraticBezierTo(pts[i].x, pts[i].y, mx, my)
    }
    p.lineTo(pts.last().x, pts.last().y)
    if (close) p.close()
    return p
}

// ═════════════════════════════════════════════════════════════════════════════
//  MOTION  (whole-body pose + per-point "vertex" wobble => legs, wings, tail ...)
// ═════════════════════════════════════════════════════════════════════════════

private class Pose(
    var dx: Float = 0f,
    var dy: Float = 0f,
    var rot: Float = 0f,
    var sx: Float = 1f,
    var sy: Float = 1f,
    var flip: Float = 1f,
    var pivotY: Float = 0f
)

private fun poseFor(m: Motion, t: Float, areaW: Float, wk: Float, hk: Float): Pose {
    val p = Pose()
    when (m) {
        Motion.WALK -> {
            val ph = t * 0.5f
            p.dx = sin(ph) * areaW * 0.28f
            p.flip = if (cos(ph) >= 0f) 1f else -1f
            p.dy = -abs(sin(t * 7f)) * hk * 0.06f
            p.sy = 1f + 0.04f * sin(t * 14f)
            p.rot = sin(t * 7f) * 2f
        }
        Motion.FLY -> {
            val ph = t * 0.8f
            p.dx = sin(ph) * areaW * 0.3f
            p.dy = sin(t * 1.6f) * hk * 0.35f
            p.flip = if (cos(ph) >= 0f) 1f else -1f
            p.rot = cos(ph) * 5f
        }
        Motion.SWIM -> {
            val ph = t * 0.6f
            p.dx = sin(ph) * areaW * 0.3f
            p.dy = sin(t * 1.7f) * hk * 0.12f
            p.flip = if (cos(ph) >= 0f) 1f else -1f
            p.rot = sin(t * 1.7f) * 4f
        }
        Motion.SPIN -> {
            p.rot = t * 60f
            val pulse = 1f + 0.07f * sin(t * 3f)
            p.sx = pulse
            p.sy = pulse
        }
        Motion.SWAY -> {
            val br = 1f + 0.015f * sin(t * 2f)
            p.sx = br
            p.sy = br
        }
        Motion.DRIVE -> {
            val travel = areaW + 2f * wk
            p.dx = -areaW / 2f - wk + ((t * 0.2f) % 1f) * travel
            p.dy = sin(t * 18f) * hk * 0.012f
            p.rot = sin(t * 12f) * 0.8f
        }
        Motion.FLOAT -> {
            p.dy = sin(t * 1.2f) * hk * 0.12f
            p.dx = sin(t * 0.7f) * wk * 0.12f
            p.rot = sin(t * 0.9f) * 5f
        }
        Motion.BOUNCE -> {
            val b = abs(sin(t * 3.2f))
            p.dy = -b * hk * 0.35f
            p.sy = 0.82f + 0.23f * b
            p.sx = 1.12f - 0.14f * b
            p.pivotY = hk / 2f
        }
        Motion.WOBBLE -> {
            p.dy = sin(t * 2f) * hk * 0.05f
            p.rot = sin(t * 1.5f) * 4f
        }
    }
    return p
}

private fun displacement(m: Motion, t: Float, u: Float, v: Float, wk: Float, hk: Float): Offset {
    return when (m) {
        Motion.WALK -> if (v > 0.68f) {
            val k = (v - 0.68f) / 0.32f
            Offset(sin(t * 14f + u * 7f) * wk * 0.035f * k, 0f)          // legs shuffle
        } else Offset.Zero
        Motion.FLY -> {
            val edge = abs(u - 0.5f) * 2f
            Offset(0f, -sin(t * 13f) * hk * 0.22f * edge.pow(1.5f))      // wings flap
        }
        Motion.SWIM -> {
            val edge = abs(u - 0.5f) * 2f
            Offset(0f, sin(t * 9f - u * 7f) * hk * 0.10f * edge)         // tail wave
        }
        Motion.SWAY -> {
            val k = 1f - v
            Offset(sin(t * 2.2f + v * 2f) * wk * 0.08f * k * k, 0f)      // top sways more
        }
        Motion.DRIVE -> if (v > 0.7f) Offset(0f, sin(t * 20f + u * 9f) * hk * 0.012f) else Offset.Zero
        Motion.WOBBLE -> Offset(sin(t * 5f + v * 8f) * wk * 0.03f, cos(t * 4.3f + u * 8f) * hk * 0.03f)
        else -> Offset.Zero
    }
}

// ═════════════════════════════════════════════════════════════════════════════
//  DRAWING
// ═════════════════════════════════════════════════════════════════════════════

/** [intro] 0..1 : pop-in + colours fade in ("comes alive"). */
fun DrawScope.drawAliveDoodle(
    d: Doodle,
    theme: DoodleTheme,
    t: Float,
    intro: Float,
    baseCx: Float,
    baseCy: Float,
    groundY: Float?
) {
    val k = doodleScale(size)
    val wk = d.w * k
    val hk = d.h * k
    val pose = poseFor(theme.motion, t, size.width, wk, hk)
    val introC = intro.coerceIn(0f, 1f)
    val pop = 1f + 0.25f * sin(introC * PI.toFloat())
    val lw = min(size.width, size.height) * 0.011f
    val ink = Color(0xFF263238)

    val rad = pose.rot * (PI.toFloat() / 180f)
    val cosR = cos(rad)
    val sinR = sin(rad)

    fun xf(p: Offset, uv: Offset): Offset {
        val disp = displacement(theme.motion, t, uv.x, uv.y, wk, hk)
        var x = p.x * k + disp.x
        var y = p.y * k + disp.y
        x *= pose.flip
        y = pose.pivotY + (y - pose.pivotY) * pose.sy * pop
        x *= pose.sx * pop
        val rx = x * cosR - y * sinR
        val ry = x * sinR + y * cosR
        return Offset(baseCx + pose.dx + rx, baseCy + pose.dy + ry)
    }

    // soft shadow on the ground
    if (groundY != null) {
        val sw = wk * 0.6f
        drawOval(
            Color.Black.copy(alpha = 0.16f),
            topLeft = Offset(baseCx + pose.dx - sw / 2f, groundY - 2f),
            size = Size(sw, 16f)
        )
    }

    for (st in d.strokes) {
        val pts = st.pts.indices.map { xf(st.pts[it], st.uv[it]) }
        val target = theme.palette[st.rank % theme.palette.size]
        val shown = lerp(Color.White, target, introC)

        when {
            st.eye -> {
                val cxy = Offset(pts.map { it.x }.average().toFloat(), pts.map { it.y }.average().toFloat())
                val r = max(lw * 2.2f, pts.map { (it - cxy).getDistance() }.average().toFloat())
                drawCircle(Color.White, r, cxy)
                drawCircle(ink, r, cxy, style = Stroke(lw * 0.8f))
                val look = Offset(sin(t * 1.7f) * r * 0.3f, cos(t * 1.3f) * r * 0.2f)
                drawCircle(ink, r * 0.45f, cxy + look)
            }
            st.closed -> {
                val path = smoothPath(pts, true)
                drawPath(path, shown, alpha = 0.92f)
                drawPath(path, ink, style = Stroke(lw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            else -> {
                val path = smoothPath(pts)
                drawPath(path, ink, style = Stroke(lw * 2.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(path, shown, style = Stroke(lw * 1.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

private fun heartPath(cx: Float, cy: Float, s: Float): Path = Path().apply {
    moveTo(cx, cy + s * 0.9f)
    cubicTo(cx - s * 1.4f, cy + s * 0.1f, cx - s * 0.9f, cy - s * 0.9f, cx, cy - s * 0.3f)
    cubicTo(cx + s * 0.9f, cy - s * 0.9f, cx + s * 1.4f, cy + s * 0.1f, cx, cy + s * 0.9f)
    close()
}

private fun DrawScope.sparkle(c: Offset, r: Float, col: Color) {
    drawLine(col, Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = 3f, cap = StrokeCap.Round)
    drawLine(col, Offset(c.x, c.y - r), Offset(c.x, c.y + r), strokeWidth = 3f, cap = StrokeCap.Round)
    drawLine(col, Offset(c.x - r * 0.5f, c.y - r * 0.5f), Offset(c.x + r * 0.5f, c.y + r * 0.5f), strokeWidth = 2f, cap = StrokeCap.Round)
    drawLine(col, Offset(c.x - r * 0.5f, c.y + r * 0.5f), Offset(c.x + r * 0.5f, c.y - r * 0.5f), strokeWidth = 2f, cap = StrokeCap.Round)
}

private fun DrawScope.cloud(cx: Float, cy: Float, s: Float, a: Float) {
    val col = Color.White.copy(alpha = a)
    drawCircle(col, s * 0.5f, Offset(cx - s * 0.5f, cy))
    drawCircle(col, s * 0.65f, Offset(cx, cy - s * 0.2f))
    drawCircle(col, s * 0.5f, Offset(cx + s * 0.5f, cy))
}

/** Particle effects – fully stateless (positions are pure functions of time). */
fun DrawScope.drawFx(fx: Fx, t: Float, groundY: Float, focus: Offset, spread: Float) {
    val w = size.width
    val h = size.height
    when (fx) {
        Fx.NONE -> Unit
        Fx.BUBBLES -> for (i in 0 until 14) {
            val ph = (t * 0.22f + i * 0.137f) % 1f
            val x = w * ((i * 0.6180339f) % 1f) + sin(t * 2f + i) * 12f
            val y = h * (1.05f - ph * 1.1f)
            val r = 6f + (i % 4) * 4f
            drawCircle(Color.White.copy(alpha = 0.5f * (1f - ph * 0.6f)), r, Offset(x, y), style = Stroke(2.5f))
        }
        Fx.RAIN -> for (i in 0 until 28) {
            val x = w * ((i * 0.3819f) % 1f)
            val y = ((t * 0.9f + i * 0.071f) % 1f) * h
            drawLine(Color(0xFF4FC3F7).copy(alpha = 0.7f), Offset(x, y), Offset(x - 6f, y + 22f), strokeWidth = 3f, cap = StrokeCap.Round)
        }
        Fx.SPARKLE -> for (i in 0 until 10) {
            val a = i * 2.4f + t * 0.5f
            val r = spread * (0.55f + 0.2f * sin(t * 2f + i))
            val tw = abs(sin(t * 3f + i))
            sparkle(Offset(focus.x + cos(a) * r, focus.y + sin(a) * r * 0.8f), 8f + 10f * tw, Color(0xFFFFF176).copy(alpha = 0.3f + 0.7f * tw))
        }
        Fx.HEARTS -> for (i in 0 until 8) {
            val ph = (t * 0.3f + i * 0.125f) % 1f
            val x = focus.x + sin(i * 5f + t) * spread * 0.5f
            val y = focus.y - ph * spread * 1.1f
            drawPath(heartPath(x, y, 14f + (i % 3) * 5f), Color(0xFFFF4081).copy(alpha = 1f - ph))
        }
        Fx.LEAVES -> for (i in 0 until 10) {
            val ph = (t * 0.18f + i * 0.1f) % 1f
            val x = w * ((i * 0.6180339f) % 1f) + sin(t + i) * 30f
            val y = ph * groundY
            rotate(t * 90f + i * 40f, Offset(x, y)) {
                drawOval(Color(0xFF7CB342).copy(alpha = 0.85f), Offset(x - 10f, y - 5f), Size(20f, 10f))
            }
        }
        Fx.SPEED -> for (i in 0 until 8) {
            val x = w * (1f - ((t * 1.5f + i * 0.13f) % 1f))
            val y = groundY - spread * (0.1f + ((i * 0.37f) % 1f) * 0.8f)
            drawLine(Color.White.copy(alpha = 0.7f), Offset(x, y), Offset(x + w * 0.08f, y), strokeWidth = 4f, cap = StrokeCap.Round)
        }
    }
}

/** Background scene behind the living doodle. */
fun DrawScope.drawScene(scene: Scene, t: Float, groundY: Float) {
    val w = size.width
    val h = size.height
    val top: Color
    val bottom: Color
    when (scene) {
        Scene.GROUND, Scene.SKY -> { top = c(0x4FC3F7); bottom = c(0xE1F5FE) }
        Scene.WATER -> { top = c(0x0288D1); bottom = c(0x01579B) }
        Scene.NIGHT -> { top = c(0x1A237E); bottom = c(0x4A148C) }
    }
    drawRect(Brush.verticalGradient(listOf(top, bottom)), size = size)

    when (scene) {
        Scene.GROUND, Scene.SKY -> {
            drawCircle(Color(0xFFFFEB3B), w * 0.07f, Offset(w * 0.85f, h * 0.12f))
            for (i in 0 until 3) {
                val x = ((t * 18f + i * w * 0.45f) % (w + 300f)) - 150f
                cloud(x, h * (0.12f + i * 0.09f), w * 0.09f, 0.9f)
            }
            if (scene == Scene.GROUND) {
                drawRect(c(0x66BB6A), Offset(0f, groundY), Size(w, h - groundY))
                drawRect(c(0x43A047), Offset(0f, groundY), Size(w, 10f))
            }
        }
        Scene.WATER -> for (i in 0 until 3) {
            val base = h * (0.12f + 0.05f * i)
            val path = Path().apply {
                moveTo(0f, base)
                var x = 0f
                while (x <= w) {
                    lineTo(x, base + sin(x * 0.02f + t * (1f + i)) * 10f)
                    x += 20f
                }
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(path, Color.White.copy(alpha = 0.08f))
        }
        Scene.NIGHT -> for (i in 0 until 40) {
            val x = w * ((i * 0.6180339f) % 1f)
            val y = h * (((i * 0.3819660f * 3f) % 1f) * 0.8f)
            drawCircle(Color.White.copy(alpha = 0.3f + 0.7f * abs(sin(t * 1.5f + i))), 2.5f, Offset(x, y))
        }
    }
}
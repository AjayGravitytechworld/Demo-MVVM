package com.example.sqliteapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEditActivity extends AppCompatActivity {

    private EditText etName, etAge, etEmail, etPhone, etCity;
    private Button btnSave, btnCancel;
    private TextView tvTitle;

    private DatabaseHelper dbHelper;
    private int studentId = -1; // -1 means ADD mode
    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        dbHelper  = new DatabaseHelper(this);

        // Views
        tvTitle   = findViewById(R.id.tvFormTitle);
        etName    = findViewById(R.id.etName);
        etAge     = findViewById(R.id.etAge);
        etEmail   = findViewById(R.id.etEmail);
        etPhone   = findViewById(R.id.etPhone);
        etCity    = findViewById(R.id.etCity);
        btnSave   = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        // Check if EDIT mode
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("student_id")) {
            isEditMode = true;
            studentId  = extras.getInt("student_id");
            tvTitle.setText("✏️ Student Edit Karo");
            btnSave.setText("Update");

            // Pre-fill fields
            etName.setText(extras.getString("student_name"));
            etAge.setText(String.valueOf(extras.getInt("student_age")));
            etEmail.setText(extras.getString("student_email"));
            etPhone.setText(extras.getString("student_phone"));
            etCity.setText(extras.getString("student_city"));
        } else {
            tvTitle.setText("➕ Naya Student Add Karo");
            btnSave.setText("Save");
        }

        btnSave.setOnClickListener(v -> saveStudent());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void saveStudent() {
        String name  = etName.getText().toString().trim();
        String ageStr= etAge.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String city  = etCity.getText().toString().trim();

        // Validation
        if (TextUtils.isEmpty(name)) {
            etName.setError("Naam dalna zaroori hai!");
            etName.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(ageStr)) {
            etAge.setError("Umar dalna zaroori hai!");
            etAge.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email dalna zaroori hai!");
            etEmail.requestFocus();
            return;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Sahi email format likhein!");
            etEmail.requestFocus();
            return;
        }

        int age = Integer.parseInt(ageStr);
        if (age <= 0 || age >= 150) {
            etAge.setError("Sahi umar likhein (1-149)!");
            etAge.requestFocus();
            return;
        }

        if (isEditMode) {
            // UPDATE
            int rows = dbHelper.updateStudent(studentId, name, age, email, phone, city);
            if (rows > 0) {
                Toast.makeText(this, "✅ Student update ho gaya!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "❌ Update failed!", Toast.LENGTH_SHORT).show();
            }
        } else {
            // INSERT
            long id = dbHelper.insertStudent(name, age, email, phone, city);
            if (id > 0) {
                Toast.makeText(this, "✅ Student add ho gaya! ID: " + id, Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "❌ Add failed! (Email duplicate ho sakta hai)", Toast.LENGTH_LONG).show();
            }
        }
    }
}

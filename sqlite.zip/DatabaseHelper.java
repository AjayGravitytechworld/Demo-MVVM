package com.example.sqliteapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper - SQLite ka pura use:
 * - onCreate, onUpgrade, onDowngrade, onOpen
 * - CRUD operations (Create, Read, Update, Delete)
 * - Transactions
 * - Raw Query
 * - Cursor operations
 * - Multiple tables
 * - Foreign Keys
 * - Index
 * - Aggregation queries (COUNT, SUM, AVG, MAX, MIN)
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // ===================== DATABASE CONSTANTS =====================
    private static final String DATABASE_NAME = "StudentDB.db";
    private static final int DATABASE_VERSION = 2; // Version 2 for onUpgrade demo

    // ===================== TABLE: students =====================
    public static final String TABLE_STUDENTS       = "students";
    public static final String COL_ID               = "id";
    public static final String COL_NAME             = "name";
    public static final String COL_AGE              = "age";
    public static final String COL_EMAIL            = "email";
    public static final String COL_PHONE            = "phone";
    public static final String COL_CITY             = "city";
    public static final String COL_CREATED_AT       = "created_at";

    // ===================== TABLE: courses =====================
    public static final String TABLE_COURSES        = "courses";
    public static final String COL_COURSE_ID        = "course_id";
    public static final String COL_COURSE_NAME      = "course_name";
    public static final String COL_STUDENT_FK       = "student_id"; // Foreign Key
    public static final String COL_MARKS            = "marks";
    public static final String COL_GRADE            = "grade";

    // ===================== CREATE TABLE SQL =====================
    private static final String CREATE_TABLE_STUDENTS =
            "CREATE TABLE " + TABLE_STUDENTS + " ("
            + COL_ID         + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_NAME       + " TEXT NOT NULL, "
            + COL_AGE        + " INTEGER CHECK(age > 0 AND age < 150), "
            + COL_EMAIL      + " TEXT UNIQUE NOT NULL, "
            + COL_PHONE      + " TEXT, "
            + COL_CITY       + " TEXT DEFAULT 'Unknown', "
            + COL_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ");";

    private static final String CREATE_TABLE_COURSES =
            "CREATE TABLE " + TABLE_COURSES + " ("
            + COL_COURSE_ID   + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_COURSE_NAME + " TEXT NOT NULL, "
            + COL_STUDENT_FK  + " INTEGER, "
            + COL_MARKS       + " REAL DEFAULT 0.0, "
            + COL_GRADE       + " TEXT, "
            + "FOREIGN KEY(" + COL_STUDENT_FK + ") REFERENCES "
            + TABLE_STUDENTS + "(" + COL_ID + ") ON DELETE CASCADE"
            + ");";

    // Index for faster search
    private static final String CREATE_INDEX_EMAIL =
            "CREATE INDEX IF NOT EXISTS idx_email ON " + TABLE_STUDENTS + "(" + COL_EMAIL + ");";

    private static final String CREATE_INDEX_STUDENT_FK =
            "CREATE INDEX IF NOT EXISTS idx_student_fk ON " + TABLE_COURSES + "(" + COL_STUDENT_FK + ");";

    // ===================== CONSTRUCTOR =====================
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // ===================== onCreate =====================
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Enable Foreign Key support
        db.execSQL("PRAGMA foreign_keys = ON;");

        // Create tables
        db.execSQL(CREATE_TABLE_STUDENTS);
        db.execSQL(CREATE_TABLE_COURSES);

        // Create indexes
        db.execSQL(CREATE_INDEX_EMAIL);
        db.execSQL(CREATE_INDEX_STUDENT_FK);

        // Insert default/seed data
        insertSeedData(db);
    }

    // ===================== onUpgrade =====================
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 → 2: Add 'phone' column if not exists
        if (oldVersion < 2) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_STUDENTS + " ADD COLUMN " + COL_PHONE + " TEXT;");
            } catch (Exception e) {
                // Column may already exist
            }
        }
        // For full reset: drop and recreate (optional)
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSES);
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        // onCreate(db);
    }

    // ===================== onDowngrade =====================
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle downgrade - drop new tables and recreate old schema
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        onCreate(db);
    }

    // ===================== onOpen =====================
    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // Enable foreign keys every time DB is opened
        if (!db.isReadOnly()) {
            db.execSQL("PRAGMA foreign_keys = ON;");
        }
    }

    // ===================== SEED DATA =====================
    private void insertSeedData(SQLiteDatabase db) {
        String[][] students = {
            {"Rahul Sharma",  "21", "rahul@gmail.com",  "9876543210", "Mumbai"},
            {"Priya Patel",   "20", "priya@gmail.com",  "9988776655", "Surat"},
            {"Amit Kumar",    "22", "amit@gmail.com",   "9123456780", "Delhi"},
            {"Sneha Joshi",   "19", "sneha@gmail.com",  "9000011111", "Ahmedabad"},
            {"Ravi Verma",    "23", "ravi@gmail.com",   "8888888888", "Jaipur"},
        };
        for (String[] s : students) {
            ContentValues cv = new ContentValues();
            cv.put(COL_NAME,  s[0]);
            cv.put(COL_AGE,   Integer.parseInt(s[1]));
            cv.put(COL_EMAIL, s[2]);
            cv.put(COL_PHONE, s[3]);
            cv.put(COL_CITY,  s[4]);
            db.insert(TABLE_STUDENTS, null, cv);
        }

        // Courses
        String[][] courses = {
            {"Mathematics",  "1", "88.5",  "A"},
            {"Science",      "1", "75.0",  "B"},
            {"English",      "2", "92.0",  "A+"},
            {"Mathematics",  "2", "60.0",  "C"},
            {"Computer",     "3", "95.5",  "A+"},
            {"History",      "4", "45.0",  "F"},
            {"Mathematics",  "5", "70.0",  "B"},
        };
        for (String[] c : courses) {
            ContentValues cv = new ContentValues();
            cv.put(COL_COURSE_NAME, c[0]);
            cv.put(COL_STUDENT_FK,  Integer.parseInt(c[1]));
            cv.put(COL_MARKS,       Double.parseDouble(c[2]));
            cv.put(COL_GRADE,       c[3]);
            db.insert(TABLE_COURSES, null, cv);
        }
    }

    // ======================================================
    //                  CRUD - STUDENTS
    // ======================================================

    /** INSERT: Add new student, returns new row ID (-1 if failed) */
    public long insertStudent(String name, int age, String email, String phone, String city) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME,  name);
        cv.put(COL_AGE,   age);
        cv.put(COL_EMAIL, email);
        cv.put(COL_PHONE, phone);
        cv.put(COL_CITY,  city);
        long id = db.insert(TABLE_STUDENTS, null, cv);
        db.close();
        return id;
    }

    /** READ ALL: Get all students as list */
    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // query(table, columns, selection, selectionArgs, groupBy, having, orderBy, limit)
        Cursor cursor = db.query(
                TABLE_STUDENTS,
                null,         // all columns
                null,         // no WHERE
                null,
                null,
                null,
                COL_NAME + " ASC",  // ORDER BY name
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Student s = cursorToStudent(cursor);
                list.add(s);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return list;
    }

    /** READ ONE: Get student by ID */
    public Student getStudentById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_STUDENTS,
                null,
                COL_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null
        );
        Student student = null;
        if (cursor != null && cursor.moveToFirst()) {
            student = cursorToStudent(cursor);
            cursor.close();
        }
        db.close();
        return student;
    }

    /** SEARCH: Search by name (LIKE) */
    public List<Student> searchStudentByName(String keyword) {
        List<Student> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_STUDENTS,
                null,
                COL_NAME + " LIKE ?",
                new String[]{"%" + keyword + "%"},
                null, null,
                COL_NAME + " ASC"
        );
        if (cursor != null && cursor.moveToFirst()) {
            do { list.add(cursorToStudent(cursor)); } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return list;
    }

    /** SEARCH by city */
    public List<Student> getStudentsByCity(String city) {
        List<Student> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_STUDENTS, null,
                COL_CITY + "=?", new String[]{city},
                null, null, null
        );
        if (cursor != null && cursor.moveToFirst()) {
            do { list.add(cursorToStudent(cursor)); } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return list;
    }

    /** UPDATE: Update student by ID, returns rows affected */
    public int updateStudent(int id, String name, int age, String email, String phone, String city) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME,  name);
        cv.put(COL_AGE,   age);
        cv.put(COL_EMAIL, email);
        cv.put(COL_PHONE, phone);
        cv.put(COL_CITY,  city);
        int rows = db.update(TABLE_STUDENTS, cv, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    /** DELETE: Delete student by ID (cascade deletes courses too) */
    public int deleteStudent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_STUDENTS, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    /** DELETE ALL students */
    public void deleteAllStudents() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_STUDENTS, null, null);
        db.close();
    }

    // ======================================================
    //              AGGREGATION QUERIES
    // ======================================================

    /** COUNT total students */
    public int getTotalStudents() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_STUDENTS, null);
        int count = 0;
        if (cursor != null && cursor.moveToFirst()) {
            count = cursor.getInt(0);
            cursor.close();
        }
        db.close();
        return count;
    }

    /** AVG age of students */
    public double getAverageAge() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT AVG(" + COL_AGE + ") FROM " + TABLE_STUDENTS, null);
        double avg = 0;
        if (cursor != null && cursor.moveToFirst()) {
            avg = cursor.getDouble(0);
            cursor.close();
        }
        db.close();
        return avg;
    }

    /** MAX marks in a course */
    public double getMaxMarks() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT MAX(" + COL_MARKS + ") FROM " + TABLE_COURSES, null);
        double max = 0;
        if (cursor != null && cursor.moveToFirst()) {
            max = cursor.getDouble(0);
            cursor.close();
        }
        db.close();
        return max;
    }

    /** MIN marks */
    public double getMinMarks() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT MIN(" + COL_MARKS + ") FROM " + TABLE_COURSES, null);
        double min = 0;
        if (cursor != null && cursor.moveToFirst()) {
            min = cursor.getDouble(0);
            cursor.close();
        }
        db.close();
        return min;
    }

    /** SUM of all marks */
    public double getSumMarks() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(" + COL_MARKS + ") FROM " + TABLE_COURSES, null);
        double sum = 0;
        if (cursor != null && cursor.moveToFirst()) {
            sum = cursor.getDouble(0);
            cursor.close();
        }
        db.close();
        return sum;
    }

    // ======================================================
    //              JOIN QUERY (Students + Courses)
    // ======================================================

    /** Raw JOIN query: student name + course + marks */
    public List<String> getStudentCoursesJoin() {
        List<String> result = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT s." + COL_NAME + ", c." + COL_COURSE_NAME + ", c." + COL_MARKS + ", c." + COL_GRADE
                + " FROM " + TABLE_STUDENTS + " s"
                + " INNER JOIN " + TABLE_COURSES + " c"
                + " ON s." + COL_ID + " = c." + COL_STUDENT_FK
                + " ORDER BY s." + COL_NAME + " ASC";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String line = cursor.getString(0) + " | " + cursor.getString(1)
                        + " | " + cursor.getDouble(2) + " | " + cursor.getString(3);
                result.add(line);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return result;
    }

    // ======================================================
    //              TRANSACTION EXAMPLE
    // ======================================================

    /** Transaction: insert multiple students atomically */
    public boolean insertStudentsBatch(List<Student> students) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            for (Student s : students) {
                ContentValues cv = new ContentValues();
                cv.put(COL_NAME,  s.getName());
                cv.put(COL_AGE,   s.getAge());
                cv.put(COL_EMAIL, s.getEmail());
                cv.put(COL_PHONE, s.getPhone());
                cv.put(COL_CITY,  s.getCity());
                db.insertOrThrow(TABLE_STUDENTS, null, cv);
            }
            db.setTransactionSuccessful(); // Commit
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Rollback on error
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    // ======================================================
    //              CURSOR HELPER
    // ======================================================

    /** Convert Cursor row → Student object, using getColumnIndexOrThrow */
    private Student cursorToStudent(Cursor cursor) {
        // getColumnIndexOrThrow throws if column not found (safe)
        int id       = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
        String name  = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME));
        int age      = cursor.getInt(cursor.getColumnIndexOrThrow(COL_AGE));
        String email = cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL));

        // getColumnIndex returns -1 if not found (safe null check)
        int phoneIdx = cursor.getColumnIndex(COL_PHONE);
        String phone = (phoneIdx != -1 && !cursor.isNull(phoneIdx)) ? cursor.getString(phoneIdx) : "";

        int cityIdx  = cursor.getColumnIndex(COL_CITY);
        String city  = (cityIdx != -1 && !cursor.isNull(cityIdx)) ? cursor.getString(cityIdx) : "";

        int dateIdx  = cursor.getColumnIndex(COL_CREATED_AT);
        String date  = (dateIdx != -1 && !cursor.isNull(dateIdx)) ? cursor.getString(dateIdx) : "";

        return new Student(id, name, age, email, phone, city, date);
    }

    // ======================================================
    //              COURSES CRUD
    // ======================================================

    public long insertCourse(int studentId, String courseName, double marks, String grade) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_STUDENT_FK,  studentId);
        cv.put(COL_COURSE_NAME, courseName);
        cv.put(COL_MARKS,       marks);
        cv.put(COL_GRADE,       grade);
        long id = db.insert(TABLE_COURSES, null, cv);
        db.close();
        return id;
    }

    public List<String> getCoursesByStudent(int studentId) {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_COURSES, null,
                COL_STUDENT_FK + "=?", new String[]{String.valueOf(studentId)},
                null, null, null
        );
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String line = cursor.getString(cursor.getColumnIndexOrThrow(COL_COURSE_NAME))
                        + " | " + cursor.getDouble(cursor.getColumnIndexOrThrow(COL_MARKS))
                        + " | " + cursor.getString(cursor.getColumnIndexOrThrow(COL_GRADE));
                list.add(line);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return list;
    }

    public int deleteCourse(int courseId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_COURSES, COL_COURSE_ID + "=?", new String[]{String.valueOf(courseId)});
        db.close();
        return rows;
    }
}

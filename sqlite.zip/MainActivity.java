package com.example.sqliteapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements StudentAdapter.OnStudentClickListener {

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private List<Student> studentList;
    private EditText etSearch;
    private TextView tvStats;
    private FloatingActionButton fabAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Init DB
        dbHelper = new DatabaseHelper(this);

        // Views
        recyclerView = findViewById(R.id.recyclerView);
        etSearch     = findViewById(R.id.etSearch);
        tvStats      = findViewById(R.id.tvStats);
        fabAdd       = findViewById(R.id.fabAdd);

        // RecyclerView setup
        studentList = new ArrayList<>();
        adapter = new StudentAdapter(this, studentList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Load data
        loadStudents();

        // FAB - Add new student
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            startActivity(intent);
        });

        // Search
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();
                if (query.isEmpty()) {
                    loadStudents();
                } else {
                    List<Student> results = dbHelper.searchStudentByName(query);
                    adapter.updateList(results);
                    tvStats.setText("Found: " + results.size() + " students");
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStudents(); // Refresh after add/edit
    }

    private void loadStudents() {
        List<Student> list = dbHelper.getAllStudents();
        adapter.updateList(list);
        updateStats();
    }

    private void updateStats() {
        int total       = dbHelper.getTotalStudents();
        double avgAge   = dbHelper.getAverageAge();
        double maxMarks = dbHelper.getMaxMarks();
        double minMarks = dbHelper.getMinMarks();

        String stats = "Total: " + total
                + "  |  Avg Age: " + String.format("%.1f", avgAge)
                + "  |  Max Marks: " + maxMarks
                + "  |  Min Marks: " + minMarks;
        tvStats.setText(stats);
    }

    // ===================== Adapter Callbacks =====================

    @Override
    public void onEditClick(Student student) {
        Intent intent = new Intent(this, AddEditActivity.class);
        intent.putExtra("student_id",    student.getId());
        intent.putExtra("student_name",  student.getName());
        intent.putExtra("student_age",   student.getAge());
        intent.putExtra("student_email", student.getEmail());
        intent.putExtra("student_phone", student.getPhone());
        intent.putExtra("student_city",  student.getCity());
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(Student student, int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Student")
                .setMessage("Kya aap '" + student.getName() + "' ko delete karna chahte hain?\n(Iske courses bhi delete ho jayenge)")
                .setPositiveButton("Haan", (dialog, which) -> {
                    int rows = dbHelper.deleteStudent(student.getId());
                    if (rows > 0) {
                        adapter.removeItem(position);
                        updateStats();
                        Toast.makeText(this, student.getName() + " deleted!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Nahi", null)
                .show();
    }

    @Override
    public void onItemClick(Student student) {
        // Show student details with courses
        List<String> courses = dbHelper.getCoursesByStudent(student.getId());
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(student.getId()).append("\n");
        sb.append("Name: ").append(student.getName()).append("\n");
        sb.append("Age: ").append(student.getAge()).append("\n");
        sb.append("Email: ").append(student.getEmail()).append("\n");
        sb.append("Phone: ").append(student.getPhone()).append("\n");
        sb.append("City: ").append(student.getCity()).append("\n");
        sb.append("Created: ").append(student.getCreatedAt()).append("\n\n");
        sb.append("📚 Courses:\n");
        if (courses.isEmpty()) {
            sb.append("  Koi course nahi");
        } else {
            for (String c : courses) sb.append("  • ").append(c).append("\n");
        }

        new AlertDialog.Builder(this)
                .setTitle("Student Details")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    // ===================== Menu =====================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_stats) {
            showFullStats();
            return true;
        } else if (id == R.id.menu_join) {
            showJoinData();
            return true;
        } else if (id == R.id.menu_delete_all) {
            confirmDeleteAll();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showFullStats() {
        int total       = dbHelper.getTotalStudents();
        double avgAge   = dbHelper.getAverageAge();
        double maxMarks = dbHelper.getMaxMarks();
        double minMarks = dbHelper.getMinMarks();
        double sumMarks = dbHelper.getSumMarks();

        String msg = "📊 Statistics:\n\n"
                + "Total Students: "     + total + "\n"
                + "Average Age: "        + String.format("%.2f", avgAge) + "\n"
                + "Max Marks (Courses): "+ maxMarks + "\n"
                + "Min Marks (Courses): "+ minMarks + "\n"
                + "Sum of All Marks: "   + sumMarks;

        new AlertDialog.Builder(this)
                .setTitle("Database Stats")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }

    private void showJoinData() {
        List<String> joinData = dbHelper.getStudentCoursesJoin();
        StringBuilder sb = new StringBuilder("🔗 Students + Courses (JOIN):\n\n");
        for (String row : joinData) {
            sb.append("• ").append(row).append("\n");
        }
        if (joinData.isEmpty()) sb.append("Koi data nahi");

        new AlertDialog.Builder(this)
                .setTitle("JOIN Query Result")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    private void confirmDeleteAll() {
        new AlertDialog.Builder(this)
                .setTitle("Delete All")
                .setMessage("Kya aap SABHI students delete karna chahte hain?")
                .setPositiveButton("Haan, Delete Karo", (dialog, which) -> {
                    dbHelper.deleteAllStudents();
                    loadStudents();
                    Toast.makeText(this, "Sab delete ho gaye!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

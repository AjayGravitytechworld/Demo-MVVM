# 🎓 Android SQLite Student Manager

## Project Structure
```
app/src/main/
├── java/com/example/sqliteapp/
│   ├── DatabaseHelper.java     ← SQLite ka pura logic
│   ├── Student.java            ← Model class
│   ├── StudentAdapter.java     ← RecyclerView Adapter
│   ├── MainActivity.java       ← Main screen (list + search)
│   └── AddEditActivity.java    ← Add / Edit form
├── res/
│   ├── layout/
│   │   ├── activity_main.xml
│   │   ├── activity_add_edit.xml
│   │   └── item_student.xml
│   ├── menu/main_menu.xml
│   ├── values/colors.xml, strings.xml, themes.xml
│   └── drawable/rounded_bg.xml
└── AndroidManifest.xml
```

---

## SQLite Features Used (DatabaseHelper.java)

| Feature | Code Location |
|---|---|
| `SQLiteOpenHelper` | Class extends it |
| `onCreate()` | Table create + seed data |
| `onUpgrade()` | ALTER TABLE to add column |
| `onDowngrade()` | Drop & recreate |
| `onOpen()` | Enable foreign_keys PRAGMA |
| `ContentValues` | Insert & Update |
| `db.insert()` | insertStudent() |
| `db.query()` | getAllStudents(), searchStudentByName() |
| `db.rawQuery()` | Aggregations + JOIN |
| `db.update()` | updateStudent() |
| `db.delete()` | deleteStudent(), deleteAllStudents() |
| `Cursor` | moveToFirst(), moveToNext(), getColumnIndexOrThrow() |
| `AUTOINCREMENT` | PRIMARY KEY in CREATE TABLE |
| `UNIQUE constraint` | email column |
| `CHECK constraint` | age > 0 AND age < 150 |
| `DEFAULT value` | city DEFAULT 'Unknown' |
| `FOREIGN KEY` | courses → students with ON DELETE CASCADE |
| `CREATE INDEX` | email, student_id |
| `COUNT()` | getTotalStudents() |
| `AVG()` | getAverageAge() |
| `MAX() / MIN()` | getMaxMarks() / getMinMarks() |
| `SUM()` | getSumMarks() |
| `INNER JOIN` | getStudentCoursesJoin() |
| `LIKE` | searchStudentByName() |
| `Transaction` | insertStudentsBatch() with beginTransaction/setTransactionSuccessful/endTransaction |
| `insertOrThrow()` | Used in batch insert |
| Multiple Tables | students + courses |

---

## Features (App UI)

- ✅ **Add Student** - FAB button se form kholein
- ✅ **Edit Student** - Pencil icon tap karo
- ✅ **Delete Student** - Trash icon + confirmation dialog
- ✅ **Delete All** - Menu → Sab Delete Karo
- ✅ **Search** - Real-time naam se search (LIKE query)
- ✅ **View Details** - Student tap karo, details + courses dikhenge
- ✅ **Statistics** - Menu → COUNT, AVG, MAX, MIN, SUM
- ✅ **JOIN Query** - Menu → Students + Courses join result
- ✅ **Validation** - Name, Age, Email required; email format check

---

## Setup Kaise Karein

1. Android Studio mein **New Project → Empty Activity** banao
2. Package name: `com.example.sqliteapp`
3. Saari files copy karo apne project mein
4. `build.gradle` mein dependencies add karo
5. **Sync Now** karo → Run karo!

---

## Database Info
- **File**: `StudentDB.db`
- **Version**: 2
- **Tables**: `students`, `courses`
- **Location** (device): `/data/data/com.example.sqliteapp/databases/StudentDB.db`

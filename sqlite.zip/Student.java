package com.example.sqliteapp;

public class Student {
    private int id;
    private String name;
    private int age;
    private String email;
    private String phone;
    private String city;
    private String createdAt;

    // Constructor - all fields
    public Student(int id, String name, int age, String email, String phone, String city, String createdAt) {
        this.id        = id;
        this.name      = name;
        this.age       = age;
        this.email     = email;
        this.phone     = phone;
        this.city      = city;
        this.createdAt = createdAt;
    }

    // Constructor - without id and date (for insert)
    public Student(String name, int age, String email, String phone, String city) {
        this.name  = name;
        this.age   = age;
        this.email = email;
        this.phone = phone;
        this.city  = city;
    }

    // Getters
    public int    getId()        { return id; }
    public String getName()      { return name; }
    public int    getAge()       { return age; }
    public String getEmail()     { return email; }
    public String getPhone()     { return phone; }
    public String getCity()      { return city; }
    public String getCreatedAt() { return createdAt; }

    // Setters
    public void setId(int id)            { this.id = id; }
    public void setName(String name)     { this.name = name; }
    public void setAge(int age)          { this.age = age; }
    public void setEmail(String email)   { this.email = email; }
    public void setPhone(String phone)   { this.phone = phone; }
    public void setCity(String city)     { this.city = city; }

    @Override
    public String toString() {
        return "ID: " + id + " | " + name + " | Age: " + age + " | " + city;
    }
}

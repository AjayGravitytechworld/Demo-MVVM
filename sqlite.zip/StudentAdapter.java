package com.example.sqliteapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {

    private Context context;
    private List<Student> studentList;
    private OnStudentClickListener listener;

    public interface OnStudentClickListener {
        void onEditClick(Student student);
        void onDeleteClick(Student student, int position);
        void onItemClick(Student student);
    }

    public StudentAdapter(Context context, List<Student> studentList, OnStudentClickListener listener) {
        this.context     = context;
        this.studentList = studentList;
        this.listener    = listener;
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_student, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = studentList.get(position);

        holder.tvName.setText(student.getName());
        holder.tvDetails.setText("Age: " + student.getAge() + "  |  " + student.getCity());
        holder.tvEmail.setText(student.getEmail());
        holder.tvPhone.setText(student.getPhone());

        // Click listeners
        holder.itemView.setOnClickListener(v -> listener.onItemClick(student));
        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(student));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(student, holder.getAdapterPosition()));
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public void updateList(List<Student> newList) {
        studentList.clear();
        studentList.addAll(newList);
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        studentList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, studentList.size());
    }

    // ===================== ViewHolder =====================
    static class StudentViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDetails, tvEmail, tvPhone;
        ImageButton btnEdit, btnDelete;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName    = itemView.findViewById(R.id.tvStudentName);
            tvDetails = itemView.findViewById(R.id.tvStudentDetails);
            tvEmail   = itemView.findViewById(R.id.tvStudentEmail);
            tvPhone   = itemView.findViewById(R.id.tvStudentPhone);
            btnEdit   = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
